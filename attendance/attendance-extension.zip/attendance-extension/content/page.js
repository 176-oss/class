/* 출결관리 도우미 - 나이스 페이지 스크립트 (MAIN world)
   나이스 페이지의 eXbuilder6 전역 객체 cpr 에 접근해 표를 읽고, 칸을 실제 마우스 이벤트로 클릭하고,
   출결마감구분 팝업을 채운다.
   절대 하지 않는 것: [적용], [저장], 출결마감, 마감취소, 출력, 장기결석 버튼 누르기.
   bridge.js(격리 world)와 window.postMessage 로만 통신한다. */
(function () {
  'use strict';
  if (window.__ahNeisPageLoaded) return; // 같은 문서에 두 번 들어오지 않도록
  window.__ahNeisPageLoaded = true;

  const CHANNEL = 'ah-neis-bridge-v1';
  const APP_MAIN = 'mis_srgaa02_m02';
  const APP_POPUP = 'mis_srgaa02_p08';
  const APP_DATE = 'udcSwcDti';
  // 확장이 절대 누르지 않는 버튼 글자
  const FORBIDDEN_LABELS = ['저장', '적용', '출결마감', '마감취소', '출력', '장기결석', '장기결석적용', '조회', '닫기', '예', '아니오'];
  // 나이스 페이지에는 tokens.css 가 없어 색을 직접 둔다 (값은 design/tokens.css 와 같게)
  const HIGHLIGHT_COLOR = '#2f5bd3';               // --c-blue-500 (--color-accent)
  const HIGHLIGHT_RING = 'rgba(47, 91, 211, 0.25)'; // --c-blue-500 25%

  let nonce = null;
  let abortSeq = 0;
  let busy = false;

  // ---------- 통신 ----------
  function post(msg) { window.postMessage(Object.assign({ channel: CHANNEL, from: 'page', nonce }, msg), '*'); }
  function emit(event) { if (nonce) post({ type: 'event', event }); }
  // 나이스 페이지 콘솔에는 아무것도 출력하지 않는다 (학생 이름 노출 방지). 기록은 사이드 패널에만.
  function log(msg, level) {
    emit({ type: 'log', level: level || 'info', msg: String(msg), at: Date.now() });
  }
  function step(n, state) { emit({ type: 'step', step: n, state: state || 'current' }); }

  class NeisError extends Error {
    constructor(code, message, data) { super(message); this.code = code; this.data = data || null; }
  }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function checkAbort(seq) {
    if (seq !== undefined && seq !== abortSeq) throw new NeisError('aborted', '작업을 멈췄습니다.');
  }
  async function waitFor(fn, opt) {
    const timeout = opt.timeout || 5000;
    const interval = opt.interval || 100;
    const t0 = Date.now();
    for (;;) {
      checkAbort(opt.seq);
      let v = null;
      try { v = fn(); } catch (e) { v = null; }
      if (v) return v;
      if (Date.now() - t0 > timeout) {
        throw new NeisError(opt.code || 'timeout', `${opt.what} (${Math.round(timeout / 1000)}초 동안 기다렸지만 확인되지 않았습니다.)`);
      }
      await sleep(interval);
    }
  }

  // ---------- cpr 접근 ----------
  function instances() {
    const P = window.cpr && window.cpr.core && window.cpr.core.Platform && window.cpr.core.Platform.INSTANCE;
    if (!P || typeof P.getAllRunningAppInstances !== 'function') return null;
    try { return P.getAllRunningAppInstances() || []; } catch (e) { return []; }
  }
  function findInst(key) {
    const list = instances() || [];
    return list.find((i) => i && i.app && String(i.app.id || '').includes(key)) || null;
  }
  function mainInst() {
    const m = findInst(APP_MAIN);
    if (!m) throw new NeisError('no_screen', '나이스 일일출결관리(담임용) 화면을 찾지 못했습니다. 나이스 > 학급담임 > 출결관리 > 일일출결관리(담임용) 화면을 열어 주세요.');
    return m;
  }
  function ctrl(inst, id) {
    const c = inst && typeof inst.lookup === 'function' ? inst.lookup(id) : null;
    if (!c) throw new NeisError('no_control', `나이스 화면에서 '${id}' 요소를 찾지 못했습니다. 화면 구조가 바뀌었을 수 있습니다.`);
    return c;
  }
  function grid() { return ctrl(mainInst(), 'grdMain'); }
  function dataSet() {
    const g = grid();
    const ds = g.dataSet || (typeof g.getDataSet === 'function' ? g.getDataSet() : null);
    if (!ds || typeof ds.getRowCount !== 'function') throw new NeisError('no_dataset', '출결 표의 데이터를 읽지 못했습니다.');
    return ds;
  }
  function dateCtrl() {
    for (const inst of instances() || []) {
      if (inst && inst.app && String(inst.app.id || '').includes(APP_DATE)) {
        const c = inst.lookup('dtiAtteYmd');
        if (c) return c;
      }
    }
    const m = findInst(APP_MAIN);
    const c = m && m.lookup('dtiAtteYmd');
    if (c) return c;
    throw new NeisError('no_control', "나이스 화면에서 일자 입력칸('dtiAtteYmd')을 찾지 못했습니다.");
  }
  const val = (ds, r, c) => { const v = ds.getValue(r, c); return v == null ? '' : String(v); };
  const isClean = (st) => st === 1 || st === 0;
  const normName = (s) => String(s || '').replace(/\s+/g, '');
  const toCompact = (d) => String(d || '').replace(/\D/g, '');
  const toDash = (c) => (c && c.length === 8 ? `${c.slice(0, 4)}-${c.slice(4, 6)}-${c.slice(6, 8)}` : '');

  // ---------- 화면 글자 ----------
  function visible(el) {
    if (!el || !el.getClientRects().length) return false;
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    const st = getComputedStyle(el);
    return st.visibility !== 'hidden' && st.display !== 'none';
  }
  function textOf(el) { return String(el.innerText != null ? el.innerText : el.textContent || '').trim(); }
  function firstLine(el) { return textOf(el).split('\n')[0].trim(); }
  function leaves(root) {
    const out = [];
    const all = root.querySelectorAll('*');
    for (const el of all) {
      if (el.tagName === 'SCRIPT' || el.tagName === 'STYLE') continue;
      const isLeaf = el.children.length === 0 || el.classList.contains('cl-text') ||
        Array.from(el.children).every((c) => c.tagName === 'BR');
      if (isLeaf) out.push(el);
    }
    return out;
  }
  function findLeaves(root, pred) { return leaves(root).filter((el) => visible(el) && pred(firstLine(el), el)); }
  const center = (el) => { const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2, r }; };

  // ---------- 화면의 학년·반, 날짜 ----------
  // 상단 조회 조건의 콤보박스 중 선택 항목 글자가 'N학년', 'N반' 인 것을 찾는다 (컨트롤 ID 에 의존하지 않음).
  // 못 찾으면 null (명단 불러올 때 선생님이 직접 확인).
  function readClassInfo() {
    const m = findInst(APP_MAIN);
    if (!m || typeof m.getContainer !== 'function') return null;
    let children = [];
    try { children = m.getContainer().getAllRecursiveChildren() || []; } catch (e) { return null; }
    let grade = null, classNo = null;
    for (const c of children) {
      if (!c || c.type !== 'combobox' || typeof c.getItems !== 'function') continue;
      let items = [];
      try { items = c.getItems() || []; } catch (e) { continue; }
      const sel = items.find((i) => String(i.value) === String(c.value));
      if (!sel) continue;
      const label = String(sel.label).trim();
      let mm;
      if (grade == null && (mm = label.match(/^(\d+)\s*학년$/))) grade = Number(mm[1]);
      else if (classNo == null && (mm = label.match(/^(\d+)\s*반$/))) classNo = Number(mm[1]);
    }
    return grade != null && classNo != null ? { grade, classNo } : null;
  }
  const koDate = (c) => (c && c.length === 8 ? `${Number(c.slice(4, 6))}월 ${Number(c.slice(6, 8))}일` : '(알 수 없음)');
  function gridYmd() {
    const ds = dataSet();
    const cols = typeof ds.getColumnNames === 'function' ? ds.getColumnNames() : [];
    if (!cols.includes('atteYmd') || !ds.getRowCount()) return null;
    return toCompact(val(ds, 0, 'atteYmd'));
  }
  // 모든 입력 단계 직전에: 나이스 일자·표 날짜·반이 세션과 같은지 확인. 다르면 즉시 멈춤.
  function assertContext(ctx) {
    if (!ctx || !ctx.date) throw new NeisError('no_context', '입력할 날짜 정보가 없습니다.');
    const target = toCompact(ctx.date);
    const ui = toCompact(dateCtrl().value);
    const gy = gridYmd();
    if (gy == null) throw new NeisError('no_grid_date', '출결 표의 날짜(atteYmd)를 읽지 못해 멈췄습니다. [조회]를 누른 뒤 다시 시도하세요.');
    if (ui !== target || gy !== target) {
      const shown = gy !== target ? gy : ui;
      throw new NeisError('date_changed', `나이스 날짜가 ${koDate(target)}이 아닙니다 (지금 화면: ${koDate(shown)}${ui !== gy ? ', 조회 전' : ''}). 날짜를 되돌리거나 [이 날짜로 이동]을 누르세요.`, { shown: toDash(shown) });
    }
    if (ctx.grade && ctx.classNo) {
      const c = readClassInfo();
      if (c && (c.grade !== Number(ctx.grade) || c.classNo !== Number(ctx.classNo))) {
        throw new NeisError('class_changed', `나이스 화면이 ${c.grade}학년 ${c.classNo}반입니다. 명단은 ${ctx.grade}학년 ${ctx.classNo}반입니다. 반을 확인하세요.`);
      }
    }
  }

  // ---------- 실제 마우스 클릭 ----------
  function forbiddenLabelOf(el) {
    let cur = el;
    for (let i = 0; cur && i < 4; i++, cur = cur.parentElement) {
      const t = textOf(cur);
      if (FORBIDDEN_LABELS.includes(t)) return t;
      if (cur.classList && cur.classList.contains('cl-grid-cell')) break;
    }
    return null;
  }
  function realClick(el, x, y) {
    if (!el) throw new NeisError('click_target', '클릭할 대상을 찾지 못했습니다.');
    const bad = forbiddenLabelOf(el);
    if (bad) throw new NeisError('forbidden', `안전을 위해 [${bad}] 버튼은 누르지 않습니다. 클릭 위치가 예상과 달라 멈췄습니다.`);
    if (x == null || y == null) { const c = center(el); x = c.x; y = c.y; }
    const base = { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y,
      screenX: x + (window.screenX || 0), screenY: y + (window.screenY || 0), button: 0 };
    const ptr = { pointerId: 1, pointerType: 'mouse', isPrimary: true };
    el.dispatchEvent(new PointerEvent('pointerover', { ...base, ...ptr, buttons: 0 }));
    el.dispatchEvent(new MouseEvent('mouseover', { ...base, buttons: 0 }));
    el.dispatchEvent(new PointerEvent('pointermove', { ...base, ...ptr, buttons: 0 }));
    el.dispatchEvent(new MouseEvent('mousemove', { ...base, buttons: 0 }));
    el.dispatchEvent(new PointerEvent('pointerdown', { ...base, ...ptr, buttons: 1 }));
    el.dispatchEvent(new MouseEvent('mousedown', { ...base, buttons: 1 }));
    el.dispatchEvent(new PointerEvent('pointerup', { ...base, ...ptr, buttons: 0 }));
    el.dispatchEvent(new MouseEvent('mouseup', { ...base, buttons: 0 }));
    el.dispatchEvent(new MouseEvent('click', { ...base, buttons: 0, detail: 1 }));
  }

  // ---------- 표 위치 찾기 ----------
  function colKeyOf(label) {
    if (label === '번호') return 'clsNo';
    if (label === '성명') return 'stuFlnm';
    if (label === '마감') return 'chulgyulGb';
    if (label === '조회') return 'jo';
    if (label === '종례') return 'jong';
    const m = label.match(/^(\d+)\s*교시/);
    return m ? `gyo${Number(m[1])}` : null;
  }
  function gridGeometry() {
    const scopes = Array.from(document.querySelectorAll('.cl-grid'));
    if (!scopes.length) scopes.push(document.body);
    for (const scope of scopes) {
      for (const noHead of findLeaves(scope, (t) => t === '번호')) {
        // 머리글('마감', '1교시')과 본문 행까지 함께 담은 가장 가까운 조상 = 표 전체
        let root = noHead.closest('.cl-grid');
        if (!root) {
          const headBottom = (noHead.closest('.cl-grid-cell') || noHead).getBoundingClientRect().bottom;
          root = noHead.parentElement;
          for (let i = 0; root && i < 16; i++, root = root.parentElement) {
            const ls = leaves(root);
            const hasHead = ls.some((e) => firstLine(e) === '마감') && ls.some((e) => /^1\s*교시/.test(firstLine(e)));
            if (hasHead && root.getBoundingClientRect().bottom > headBottom + 10) break;
          }
        }
        if (!root) continue;
        const hc = center(noHead);
        const cols = {};
        for (const el of findLeaves(root, () => true)) {
          const c = center(el);
          if (Math.abs(c.y - hc.y) > 30) continue;
          const key = colKeyOf(firstLine(el));
          if (!key || cols[key]) continue;
          const cell = el.closest('.cl-grid-cell') || el;
          const cr = cell.getBoundingClientRect();
          cols[key] = { el, cell, x: cr.left + cr.width / 2, left: cr.left, right: cr.right, label: firstLine(el) };
        }
        if (cols.clsNo && cols.chulgyulGb) {
          const headerBottom = Math.max(...Object.values(cols).map((c) => c.cell.getBoundingClientRect().bottom));
          return { root, cols, headerBottom };
        }
      }
    }
    throw new NeisError('no_grid_dom', "화면에서 출결 표의 머리글('번호', '마감', '1교시' 등)을 찾지 못했습니다.");
  }
  function locateRowDom(geo, no, name) {
    const noCol = geo.cols.clsNo, nameCol = geo.cols.stuFlnm;
    const nums = findLeaves(geo.root, (t) => t === String(no)).filter((el) => {
      const c = center(el);
      // 스크롤로 머리글 위쪽에 가려진 행도 찾는다 (뒤에서 scrollIntoView 로 보이게 함)
      return c.x >= noCol.left - 2 && c.x <= noCol.right + 2 && !noCol.cell.contains(el);
    });
    for (const numEl of nums) {
      const y = center(numEl).y;
      if (!nameCol) return { numEl, y };
      const nameEl = findLeaves(geo.root, (t) => normName(t) === normName(name)).find((el) => {
        const c = center(el);
        return Math.abs(c.y - y) < 10 && c.x >= nameCol.left - 2 && c.x <= nameCol.right + 2;
      });
      if (nameEl) return { numEl, y };
    }
    return null;
  }
  const GRID_API_CANDIDATES = ['scrollToRow', 'focusCell', 'selectRows', 'setFocusedCell', 'focusRow', 'showRow', 'revealRow', 'moveToRow', 'setScrollTop'];
  function gridApiReport() {
    try {
      const g = grid();
      const found = GRID_API_CANDIDATES.filter((k) => typeof g[k] === 'function');
      return found;
    } catch (e) { return []; }
  }
  async function findRowOnScreen(rowIdx, no, name, seq) {
    let geo = gridGeometry();
    let hit = locateRowDom(geo, no, name);
    if (!hit) {
      // 대체 전략: 그리드 API 로 행을 화면에 보이게 함
      const g = grid();
      const apis = gridApiReport();
      if (apis.length) log(`표에서 ${no}번 행이 화면에 없어 그리드 기능으로 이동을 시도합니다. 사용 가능: ${apis.join(', ')}`, 'warn');
      const tries = [
        ['scrollToRow', () => g.scrollToRow(rowIdx)],
        ['showRow', () => g.showRow(rowIdx)],
        ['revealRow', () => g.revealRow(rowIdx)],
        ['focusCell', () => g.focusCell(rowIdx, 0)],
        ['selectRows', () => g.selectRows([rowIdx])],
      ];
      for (const [k, fn] of tries) {
        if (typeof g[k] !== 'function') continue;
        try { fn(); log(`그리드 ${k}(${rowIdx}) 호출`, 'warn'); } catch (e) { log(`그리드 ${k} 실패: ${e.message}`, 'warn'); continue; }
        await sleep(300); checkAbort(seq);
        geo = gridGeometry();
        hit = locateRowDom(geo, no, name);
        if (hit) break;
      }
    }
    if (!hit) hit = await scrollGridToRow(geo, rowIdx, no, name, seq);
    if (!hit) throw new NeisError('row_not_visible', `화면의 출결 표에서 ${no}번 행을 찾지 못했습니다. 표를 스크롤해 ${no}번이 보이게 한 뒤 다시 시도하세요.`);
    hit.numEl.scrollIntoView({ block: 'center', inline: 'nearest' });
    const sc0 = scrollContainer(geo.root);
    if (sc0) sc0.dispatchEvent(new Event('scroll'));
    await sleep(150); checkAbort(seq);
    geo = gridGeometry();
    hit = locateRowDom(geo, no, name);
    if (!hit) throw new NeisError('row_not_visible', `스크롤 뒤 ${no}번 행을 다시 찾지 못했습니다.`);
    return { geo, hit };
  }
  // 가상 스크롤 그리드: 화면에 보이는 행만 DOM 에 있으므로 스크롤 영역의 scrollTop 을 옮겨 가며 번호 글자로 확인
  // scrollTop 을 바꾸고 scroll 이벤트도 바로 보냄 (탭이 뒤에 있으면 브라우저가 scroll 이벤트를 늦게 보내기 때문)
  function setScroll(sc, top) {
    sc.scrollTop = top;
    sc.dispatchEvent(new Event('scroll'));
  }
  function scrollContainer(root) {
    const cands = [root, ...root.querySelectorAll('*')].filter((el) => {
      if (el.scrollHeight <= el.clientHeight + 4) return false;
      const oy = getComputedStyle(el).overflowY;
      return oy === 'auto' || oy === 'scroll';
    });
    cands.sort((a, b) => b.scrollHeight - a.scrollHeight);
    return cands[0] || null;
  }
  function visibleNumbers(geo) {
    const col = geo.cols.clsNo;
    return findLeaves(geo.root, (t) => /^\d+$/.test(t)).filter((el) => {
      const c = center(el);
      return c.x >= col.left - 2 && c.x <= col.right + 2 && !col.cell.contains(el);
    }).map((el) => Number(firstLine(el)));
  }
  async function scrollGridToRow(geo, rowIdx, no, name, seq) {
    const sc = scrollContainer(geo.root);
    if (!sc) { log('표의 스크롤 영역을 찾지 못했습니다.', 'warn'); return null; }
    const n = dataSet().getRowCount() || 1;
    const rowH = sc.scrollHeight / n;
    setScroll(sc, Math.max(0, rowIdx * rowH - sc.clientHeight / 2));
    log(`${no}번 행을 찾기 위해 표를 스크롤합니다.`);
    for (let i = 0; i < 40; i++) {
      await sleep(150); checkAbort(seq);
      geo = gridGeometry();
      const hit = locateRowDom(geo, no, name);
      if (hit) return hit;
      const nums = visibleNumbers(geo);
      if (!nums.length) break;
      const min = Math.min(...nums), max = Math.max(...nums);
      const before = sc.scrollTop;
      const stepPx = Math.max(rowH, sc.clientHeight * 0.6);
      if (Number(no) < min) setScroll(sc, before - stepPx);
      else if (Number(no) > max) setScroll(sc, before + stepPx);
      else break; // 번호 범위 안인데 없음 -> 추측하지 않고 멈춤
      if (sc.scrollTop === before) break; // 끝에 닿음
    }
    log(`스크롤해도 ${no}번 행을 찾지 못했습니다.`, 'warn');
    return null;
  }
  async function clickCell(rowIdx, no, name, colKey, seq, ctx) {
    let { geo, hit } = await findRowOnScreen(rowIdx, no, name, seq);
    let col = geo.cols[colKey];
    if (!col) throw new NeisError('no_column', `출결 표에서 '${colLabel(colKey)}' 열을 찾지 못했습니다.`);
    if (col.x < 0 || col.x > window.innerWidth) {
      col.cell.scrollIntoView({ block: 'nearest', inline: 'center' });
      await sleep(150);
      ({ geo, hit } = await findRowOnScreen(rowIdx, no, name, seq));
      col = geo.cols[colKey];
    }
    const x = col.x, y = hit.y;
    const target = document.elementFromPoint(x, y);
    if (!target || !geo.root.contains(target)) {
      throw new NeisError('click_target', `${no}번 '${colLabel(colKey)}' 칸 위치에 다른 요소가 있어 누르지 않았습니다. 화면을 가리는 창이 있는지 확인하세요.`);
    }
    const rowA = target.closest('.cl-grid-row'), rowB = hit.numEl.closest('.cl-grid-row');
    if (rowA && rowB && rowA !== rowB) throw new NeisError('click_target', `${no}번 행과 다른 행이 클릭 위치에 있어 멈췄습니다.`);
    assertContext(ctx);
    if (Number(val(dataSet(), rowIdx, 'clsNo')) !== Number(no)) throw new NeisError('row_changed', '표 내용이 바뀌어 멈췄습니다. 다시 시도하세요.');
    realClick(target, x, y);
    log(`${no}번 '${colLabel(colKey)}' 칸 클릭`);
  }
  function colLabel(key) {
    if (key === 'chulgyulGb') return '마감';
    if (key === 'jo') return '조회';
    if (key === 'jong') return '종례';
    if (/^gyo\d+$/.test(key)) return `${key.slice(3)}교시`;
    return key;
  }

  // ---------- 행 찾기 ----------
  function findRow(no, name) {
    if (!name) throw new NeisError('no_name', `${no}번 학생 이름이 명단에 없습니다. [명단] 탭에서 나이스 명단을 먼저 불러오세요.`);
    const ds = dataSet();
    const n = ds.getRowCount();
    for (let r = 0; r < n; r++) {
      if (Number(val(ds, r, 'clsNo')) === Number(no)) {
        const actual = val(ds, r, 'stuFlnm');
        if (normName(actual) !== normName(name)) {
          throw new NeisError('name_mismatch', `${no}번 학생 이름이 명단과 나이스가 다릅니다. 명단을 다시 불러오거나 기록의 번호를 확인하세요.`, { actual, expected: name });
        }
        return r;
      }
    }
    throw new NeisError('not_found', `나이스 표에 ${no}번 학생이 없습니다.`);
  }

  // ---------- 팝업 ----------
  function popupRoot() {
    const titles = findLeaves(document.body, (t) => t === '출결마감구분');
    for (const t of titles) {
      let root = t.parentElement;
      for (let i = 0; root && i < 12; i++, root = root.parentElement) {
        const ls = leaves(root).map(firstLine);
        if (ls.includes('적용') && ls.includes('질병')) return root;
      }
    }
    return null;
  }
  async function clickPopupLabel(root, label, seq) {
    const cands = findLeaves(root, (t) => t === label);
    let el = cands.length === 1 ? cands[0] : cands.find((e) => e.closest('[class*="radio"]'));
    if (!el) throw new NeisError('popup_label', `팝업에서 '${label}' 선택지를 찾지 못했습니다.`);
    realClick(el);
    checkAbort(seq);
  }
  function setNativeValue(input, value) {
    const proto = input.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    input.focus();
    input.dispatchEvent(new FocusEvent('focus', { bubbles: false }));
    input.dispatchEvent(new FocusEvent('focusin', { bubbles: true }));
    setter.call(input, value);
    input.dispatchEvent(new InputEvent('input', { bubbles: true, data: value, inputType: 'insertText' }));
    input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Process' }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    input.blur();
  }
  function reasonInput(root) {
    const inputs = Array.from(root.querySelectorAll('input, textarea')).filter((el) => {
      const type = (el.getAttribute('type') || 'text').toLowerCase();
      return visible(el) && !['hidden', 'radio', 'checkbox', 'button', 'submit'].includes(type) && !el.readOnly && !el.disabled;
    });
    if (inputs.length === 1) return inputs[0];
    const lbl = findLeaves(root, (t) => t === '사유')[0];
    if (lbl && inputs.length) {
      const y = center(lbl).y;
      const near = inputs.filter((el) => Math.abs(center(el).y - y) < 20);
      if (near.length === 1) return near[0];
    }
    return null;
  }
  let highlighted = null;
  function highlightApply(root) {
    const lbl = findLeaves(root, (t) => t === '적용')[0];
    if (!lbl) return false;
    const btn = lbl.closest('.cl-button') || lbl;
    highlighted = { el: btn, outline: btn.style.outline, offset: btn.style.outlineOffset, shadow: btn.style.boxShadow };
    btn.style.outline = `3px solid ${HIGHLIGHT_COLOR}`;
    btn.style.outlineOffset = '2px';
    btn.style.boxShadow = `0 0 0 7px ${HIGHLIGHT_RING}`;
    return true;
  }
  function clearHighlight() {
    if (!highlighted) return;
    try {
      highlighted.el.style.outline = highlighted.outline;
      highlighted.el.style.outlineOffset = highlighted.offset;
      highlighted.el.style.boxShadow = highlighted.shadow;
    } catch (e) { /* 팝업이 이미 사라짐 */ }
    highlighted = null;
  }
  function itemLabel(control, value, fallback) {
    try {
      const items = typeof control.getItems === 'function' ? control.getItems() : [];
      const it = items.find((i) => String(i.value) === String(value));
      if (it) return String(it.label);
      if (items.length) throw new NeisError('popup_item', `팝업에 '${fallback}'(${value}) 선택지가 없습니다.`);
    } catch (e) { if (e instanceof NeisError) throw e; }
    return fallback;
  }

  // ---------- 명령 ----------
  function rowMarks(idx) {
    const ds = dataSet();
    const totMax = Number(val(ds, idx, 'totMax')) || 0;
    const m = { chulgyulGb: val(ds, idx, 'chulgyulGb'), jo: val(ds, idx, 'jo'), jong: val(ds, idx, 'jong'), gyo: {}, closed: [] };
    for (let i = 1; i <= (totMax || 10); i++) {
      m.gyo[i] = val(ds, idx, `gyo${i}`);
      if (val(ds, idx, `magamGyo${i}`) === 'Y') m.closed.push(i);
    }
    return { totMax, marks: m, clean: isClean(ds.getRowState(idx)) };
  }

  const commands = {
    async detect() {
      const list = instances();
      const m = findInst(APP_MAIN);
      const out = { cpr: !!list, neis: !!m, popupOpen: !!findInst(APP_POPUP), cls: null, ymd: '', gridYmd: '', rowCount: 0, dirtyRows: 0, gridApi: [] };
      if (m) {
        out.cls = readClassInfo();
        try { out.ymd = toDash(toCompact(dateCtrl().value)); } catch (e) { /* 없음 */ }
        try {
          out.gridYmd = toDash(gridYmd() || '');
          const ds = dataSet();
          out.rowCount = ds.getRowCount();
          for (let r = 0; r < out.rowCount; r++) if (!isClean(ds.getRowState(r))) out.dirtyRows++;
        } catch (e) { /* 없음 */ }
        out.gridApi = gridApiReport();
      }
      return out;
    },

    // 번호와 이름만 읽는다 (생년월일 등 다른 개인정보는 읽지 않음)
    async readRoster() {
      const ds = dataSet();
      const n = ds.getRowCount();
      const students = [];
      for (let r = 0; r < n; r++) {
        const no = Number(val(ds, r, 'clsNo'));
        const name = val(ds, r, 'stuFlnm').trim();
        if (no && name) students.push({ no, name });
      }
      if (!students.length) throw new NeisError('empty', '출결 표에 학생이 없습니다. [조회]를 누른 뒤 다시 시도하세요.');
      const cls = readClassInfo();
      let date = null;
      try { date = toDash(gridYmd() || ''); } catch (e) { /* 없음 */ }
      return { students, grade: cls ? cls.grade : null, classNo: cls ? cls.classNo : null, date };
    },

    // 일자 컨트롤 value 대입 -> [조회]. 표의 atteYmd 와 행 상태로 다시 불러온 것을 확인.
    async setDate({ date }, seq) {
      const target = toCompact(date);
      if (target.length !== 8) throw new NeisError('bad_date', `날짜 형식이 올바르지 않습니다: ${date}`);
      if (findInst(APP_POPUP)) throw new NeisError('popup_open', '출결마감구분 팝업이 열려 있습니다. 닫은 뒤 다시 시도하세요.');
      const ds0 = dataSet();
      for (let r = 0; r < ds0.getRowCount(); r++) {
        if (!isClean(ds0.getRowState(r))) throw new NeisError('unsaved', '저장하지 않은 변경이 있어 날짜를 바꾸지 않았습니다. 먼저 [저장]하거나 [조회]로 되돌리세요.');
      }
      if (gridYmd() == null && ds0.getRowCount()) throw new NeisError('no_grid_date', '출결 표의 날짜(atteYmd)를 읽을 수 없어 날짜를 바꾸지 않았습니다.');
      const dti = dateCtrl();
      const loaded = () => {
        const d = dataSet();
        const n = d.getRowCount();
        if (!n || toCompact(dti.value) !== target) return false;
        if (toCompact(val(d, 0, 'atteYmd')) !== target || toCompact(val(d, n - 1, 'atteYmd')) !== target) return false;
        for (let r = 0; r < n; r++) if (!isClean(d.getRowState(r))) return false;
        return true;
      };
      if (loaded()) { log(`이미 ${koDate(target)} 표입니다.`); return { date, changed: false }; }
      dti.value = target;
      if (toCompact(dti.value) !== target) throw new NeisError('date_set', '나이스 일자 입력칸에 날짜를 넣지 못했습니다.');
      ctrl(mainInst(), 'btnSearch').click();
      log(`일자를 ${koDate(target)}로 바꾸고 [조회]를 눌렀습니다.`);
      // 두 번 연속 확인되어야 다시 불러온 것으로 봄
      let okCount = 0;
      await waitFor(() => { okCount = loaded() ? okCount + 1 : 0; return okCount >= 2; },
        { timeout: 15000, interval: 250, seq, what: `${koDate(target)} 출결 표가 다시 불러와지기를 기다렸습니다.`, code: 'date_timeout' });
      return { date, changed: true };
    },

    async prepareStudent(a, seq) {
      const { no, name, ctx } = a;
      if (findInst(APP_POPUP)) throw new NeisError('popup_open', '출결마감구분 팝업이 이미 열려 있습니다. 팝업을 닫은 뒤 다시 시도하세요.');
      // 1 학생 찾기
      step(1);
      assertContext(ctx);
      const idx = findRow(no, name);
      const ds = dataSet();
      const gb = val(ds, idx, 'chulgyulGb');
      const info = rowMarks(idx);
      if (gb) {
        // 기존 값은 덮어쓰지 않는다. 비교는 사이드 패널이 교시까지 한다.
        throw new NeisError('already', `${no}번: 나이스 표에 이미 '${gb}'(이)가 입력되어 있어 덮어쓰지 않았습니다.`, info);
      }
      const combo = ctrl(mainInst(), 'cmbAtteScCd');
      if (combo.value) { log(`일괄 콤보가 '${combo.value}'여서 출석으로 되돌립니다.`, 'warn'); combo.value = ''; }
      step(1, 'done');

      // 2 팝업 열기
      step(2);
      await clickCell(idx, no, name, 'chulgyulGb', seq, ctx);
      const p = await waitFor(() => findInst(APP_POPUP), { timeout: 6000, seq, what: '마감 칸을 눌렀지만 출결마감구분 팝업이 열리지 않았습니다.', code: 'popup_not_opened' });
      const root = await waitFor(popupRoot, { timeout: 4000, seq, what: "팝업 화면('출결마감구분')을 찾지 못했습니다.", code: 'popup_dom' });
      step(2, 'done');

      // 3 구분, 종류, 사유
      step(3);
      assertContext(ctx);
      const rdbDiv = ctrl(p, 'rdbDiv'), rdbSort = ctrl(p, 'rdbSort'), ipbReason = ctrl(p, 'ipbReason');
      const divLabel = itemLabel(rdbDiv, a.divNeis, a.divKo);
      await clickPopupLabel(root, divLabel, seq);
      await waitFor(() => rdbDiv.value === a.divNeis, { timeout: 3000, seq, what: `팝업 구분에 '${divLabel}'을(를) 선택하지 못했습니다.`, code: 'popup_div' });
      await waitFor(() => rdbSort.enabled === true, { timeout: 3000, seq, what: '팝업 종류 선택 칸이 활성화되지 않았습니다.', code: 'popup_sort_disabled' });
      const sortLabel = itemLabel(rdbSort, a.sortNeis, a.kindKo);
      await clickPopupLabel(root, sortLabel, seq);
      await waitFor(() => rdbSort.value === a.sortNeis, { timeout: 3000, seq, what: `팝업 종류에 '${sortLabel}'을(를) 선택하지 못했습니다.`, code: 'popup_sort' });
      const reason = String(a.reason || '');
      if (reason) {
        const input = reasonInput(root);
        if (!input) throw new NeisError('popup_reason', '팝업에서 사유 입력칸을 찾지 못했습니다.');
        setNativeValue(input, reason);
        try {
          await waitFor(() => String(ipbReason.value) === reason, { timeout: 1500, seq, what: '사유 반영' });
        } catch (e) {
          if (e.code === 'aborted') throw e;
          log('입력칸 이벤트로 사유가 반영되지 않아 컨트롤 값을 직접 설정합니다.', 'warn');
          ipbReason.value = reason;
          await waitFor(() => String(ipbReason.value) === reason, { timeout: 1500, seq, what: '팝업 사유 칸에 사유를 넣지 못했습니다.', code: 'popup_reason' });
        }
      }
      if (rdbDiv.value !== a.divNeis || rdbSort.value !== a.sortNeis) {
        throw new NeisError('popup_verify', '팝업에 채운 값이 예상과 다릅니다. 팝업을 닫고 다시 시도하세요.');
      }
      highlightApply(root);
      step(3, 'done');
      step(4);
      log(`${no}번 팝업 채움: ${divLabel} ${sortLabel}`);
      return { rowIndex: idx, totMax: info.totMax };
    },

    // 선생님이 [적용] 또는 [닫기]를 누를 때까지 기다림
    async waitPopupClosed(a, seq) {
      await waitFor(() => !findInst(APP_POPUP), { timeout: a.timeout || 600000, interval: 250, seq, what: '선생님이 팝업의 [적용]을 누르기를 기다렸습니다.', code: 'apply_timeout' });
      clearHighlight();
      assertContext(a.ctx);
      const idx = findRow(a.no, a.name);
      let gb = '';
      try {
        await waitFor(() => (gb = val(dataSet(), idx, 'chulgyulGb')) !== '', { timeout: 1500, seq, what: '' });
      } catch (e) { if (e.code === 'aborted') throw e; }
      if (gb === a.expectedGb) return { status: 'applied', gb };
      if (!gb) return { status: 'cancelled', gb };
      return { status: 'mismatch', gb };
    },

    async markPeriods(a, seq) {
      const { no, name, kind, ctx } = a;
      assertContext(ctx);
      const idx = findRow(no, name);
      const ds = dataSet();
      const totMax = Number(val(ds, idx, 'totMax')) || 0;
      let targets = [];
      if (kind === 'late' || kind === 'early') targets = [Number(a.period)];
      else if (kind === 'result') targets = (a.periods || []).map(Number);
      for (const p of targets) {
        if (!(p >= 1) || (totMax && p > totMax)) throw new NeisError('period_range', `${p}교시는 이날 교시 수(${totMax})를 벗어납니다.`);
        if (val(ds, idx, `magamGyo${p}`) === 'Y' && val(ds, idx, `gyo${p}`) !== '/') {
          throw new NeisError('period_closed', `${p}교시는 이미 교시 마감되어 확장 프로그램이 표시할 수 없습니다. 나이스에서 직접 확인해 주세요.`);
        }
      }
      step(5);
      for (const p of targets) {
        const col = `gyo${p}`;
        if (val(dataSet(), idx, col) === '/') { log(`${no}번 ${p}교시는 이미 표시되어 있어 누르지 않습니다.`); continue; }
        await clickCell(idx, no, name, col, seq, ctx);
        await waitFor(() => val(dataSet(), idx, col) === '/', { timeout: 3000, seq, what: `${p}교시 칸을 눌렀지만 표에 '/' 표시가 생기지 않았습니다.`, code: 'click_no_effect' });
        await sleep(200);
      }
      step(5, 'done');
      step(6);
      assertContext(ctx);
      const res = compareRow(idx, a.expected || {}, a.reason);
      step(6, res.ok ? 'done' : 'error');
      return res;
    },

    async resetCombo() {
      const combo = ctrl(mainInst(), 'cmbAtteScCd');
      combo.value = '';
      if (String(combo.value) !== '') throw new NeisError('combo', "일괄 콤보를 '출석'으로 되돌리지 못했습니다.");
      return { ok: true };
    },

    // 선생님이 [저장]을 누르면: 모든 행 상태 1 + 처리한 학생 값 유지
    async waitSaved(a, seq) {
      let stable = 0;
      const t0 = Date.now();
      const timeout = a.timeout || 1800000;
      for (;;) {
        checkAbort(seq);
        let state;
        try { state = saveState(a.students, a.ctx); } catch (e) {
          if (e instanceof NeisError && (e.code === 'date_changed' || e.code === 'class_changed')) throw e;
          state = { kind: 'wait' };
        }
        if (state.kind === 'saved' || state.kind === 'reverted') stable++; else stable = 0;
        if (stable >= 3) {
          if (state.kind === 'saved') return { saved: true };
          throw new NeisError('reverted', `저장되지 않고 표가 되돌아갔습니다 (${state.missing.join(', ')}번 값 없음). [조회]를 누른 것 같습니다. 다시 입력해야 합니다.`, { missing: state.missing });
        }
        if (Date.now() - t0 > timeout) throw new NeisError('save_timeout', '[저장]을 기다리는 시간이 지났습니다.');
        await sleep(400);
      }
    },

    async abort() { abortSeq++; clearHighlight(); return { ok: true }; },
  };

  function saveState(students, ctx) {
    if (findInst(APP_POPUP)) return { kind: 'wait' };
    const ds = dataSet();
    const n = ds.getRowCount();
    if (!n) return { kind: 'wait' };
    for (let r = 0; r < n; r++) if (!isClean(ds.getRowState(r))) return { kind: 'wait' };
    assertContext(ctx);
    const missing = [];
    for (const s of students) {
      let idx;
      try { idx = findRow(s.no, s.name); } catch (e) { missing.push(s.no); continue; }
      if (val(ds, idx, 'chulgyulGb') !== s.expectedGb) missing.push(s.no);
    }
    return missing.length ? { kind: 'reverted', missing } : { kind: 'saved' };
  }

  function compareRow(idx, exp, reason) {
    const ds = dataSet();
    const totMax = Number(val(ds, idx, 'totMax')) || Object.keys(exp.gyo || {}).length;
    const actual = { chulgyulGb: val(ds, idx, 'chulgyulGb'), jo: val(ds, idx, 'jo'), jong: val(ds, idx, 'jong'), gyo: {}, atteRmkCn: val(ds, idx, 'atteRmkCn') };
    for (let i = 1; i <= totMax; i++) actual.gyo[i] = val(ds, idx, `gyo${i}`);
    const diffs = [], warnings = [];
    if (actual.chulgyulGb !== exp.chulgyulGb) diffs.push(`출결 구분이 '${actual.chulgyulGb || '(빈칸)'}'입니다. 기대값: '${exp.chulgyulGb}'`);
    const show = (v) => (v === '/' ? '표시' : '빈칸');
    if (exp.jo != null && actual.jo !== exp.jo) warnings.push(`조회: ${show(actual.jo)} (기대: ${show(exp.jo)})`);
    for (let i = 1; i <= totMax; i++) {
      const e = exp.gyo ? exp.gyo[i] : undefined;
      if (e != null && actual.gyo[i] !== e) warnings.push(`${i}교시: ${show(actual.gyo[i])} (기대: ${show(e)})`);
    }
    if (exp.jong != null && actual.jong !== exp.jong) warnings.push(`종례: ${show(actual.jong)} (기대: ${show(exp.jong)})`);
    if (reason != null && reason !== '' && actual.atteRmkCn !== reason) warnings.push(`사유가 '${actual.atteRmkCn}'입니다. 기대값: '${reason}'`);
    return { ok: diffs.length === 0, diffs, warnings, actual };
  }

  // ---------- 메시지 처리 ----------
  window.addEventListener('message', async (ev) => {
    if (ev.source !== window) return;
    const d = ev.data;
    if (!d || d.channel !== CHANNEL || d.from !== 'bridge') return;
    if (d.type === 'init') {
      if (nonce) return; // 첫 연결만 받음
      if (typeof d.nonce !== 'string' || d.nonce.length < 16) return;
      nonce = d.nonce;
      post({ type: 'inited' });
      return;
    }
    if (!nonce || d.nonce !== nonce || d.type !== 'request') return;
    const { reqId, cmd, args } = d;
    const fn = commands[cmd];
    if (!fn) { post({ type: 'response', reqId, ok: false, error: { code: 'unknown', message: `알 수 없는 명령: ${cmd}` } }); return; }
    const exclusive = !['detect', 'abort'].includes(cmd);
    if (exclusive && busy) {
      // 방금 멈춘 작업이 정리될 때까지 잠깐 기다림
      for (let i = 0; i < 40 && busy; i++) await sleep(50);
    }
    if (exclusive && busy) { post({ type: 'response', reqId, ok: false, error: { code: 'busy', message: '이전 작업이 아직 끝나지 않았습니다.' } }); return; }
    if (exclusive) busy = true;
    const seq = abortSeq;
    try {
      const result = await fn(args || {}, seq);
      post({ type: 'response', reqId, ok: true, result });
    } catch (e) {
      const err = e instanceof NeisError ? { code: e.code, message: e.message, data: e.data } : { code: 'error', message: `예상하지 못한 오류: ${e && e.message ? e.message : e}` };
      if (err.code !== 'aborted') log(err.message, 'error');
      post({ type: 'response', reqId, ok: false, error: err });
    } finally {
      if (exclusive) busy = false;
    }
  });

  post({ type: 'ready' });
})();
