/* 출결관리 도우미 - 버전 알림 스크립트 (격리 world)
   출결 기록 웹앱(https://176-oss.github.io/class/attendance/) 에서만 동작한다.
   웹앱이 '이 PC에 설치된 확장 버전'을 알 수 있도록 버전 문자열 하나만 알려 준다.
   - <html data-ah-ext-version="0.4.1">
   - window.postMessage({source:'ah-ext', type:'version', version})
   그 밖의 데이터(기록, 명단, 토큰 등)는 페이지에 절대 주지 않는다. 페이지에서 받는 메시지는 버전 재요청(ping)뿐이다. */
(function () {
  'use strict';
  if (window.__ahExtVersionLoaded) return;
  window.__ahExtVersionLoaded = true;
  const version = chrome.runtime.getManifest().version;
  const send = () => window.postMessage({ source: 'ah-ext', type: 'version', version }, location.origin);
  try { document.documentElement.dataset.ahExtVersion = version; } catch (e) { /* 무시 */ }
  window.addEventListener('message', (ev) => {
    if (ev.source !== window) return;
    const d = ev.data;
    if (d && d.source === 'ah-app' && d.type === 'ping') send();
  });
  send();
})();
