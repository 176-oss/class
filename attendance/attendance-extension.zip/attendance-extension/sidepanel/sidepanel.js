// 출결관리 도우미 - 확장 사이드 패널
import { mergeData, KINDS, DIVS, chulgyulGb, formatDateKo, describeKind } from '../shared/model.js';
import { expectedNeisMarks } from '../shared/rules.js';
import * as store from './store.js';
import * as drive from './drive.js';

const NEIS_URLS = ['https://*.neis.go.kr/*'];
const STEP_LABELS = ['학생 찾기', '팝업 열기', '구분·종류·사유 채움', '선생님이 [적용] 누르기', '교시 표시', '확인'];
const NEIS_GUIDE = '나이스 > 학급담임 > 출결관리 > 일일출결관리(담임용) 화면을 열어 주세요.';

const S = {
  rosterConfirm: null,
  tab: 'neis',
  data: null,
  roster: null,
  drive: { connected: false, lastSyncAt: null },
  conn: { state: 'checking' },
  session: null,
  logs: [],
  logOpen: false,
  syncing: false,
  rosterBusy: false,
};
let runCounter = 0;

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const kbd = (t) => `<span class="kbd">${esc(t)}</span>`;
const icon = (id) => `<svg class="icon" aria-hidden="true"><use href="#${id}"/></svg>`;
const fmtTime = (iso) => {
  if (!iso) return '';
  const d = new Date(iso);
  return `${d.getMonth() + 1}월 ${d.getDate()}일 ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
};
class PanelError extends Error { constructor(code, message, data) { super(message); this.code = code; this.data = data; } }

// ---------- 데이터 ----------
const nameOf = (no) => (S.roster && S.roster.students.find((s) => Number(s.no) === Number(no)) || {}).name || '';
function pendingRecords() {
  return (S.data ? S.data.records : []).filter((r) => !(r.neis && r.neis.done))
    .sort((a, b) => (a.date === b.date ? a.no - b.no : a.date < b.date ? -1 : 1));
}
function pendingDates() { return [...new Set(pendingRecords().map((r) => r.date))]; }
function recordLine(r) { return describeKind(r).trim(); }

// ---------- 토스트 ----------
let toastTimer = null;
function toast(msg, danger) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.toggle('toast-danger', !!danger);
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, danger ? 5000 : 2600);
}

// ---------- 나이스 탭과 통신 ----------
async function sendToTab(tabId, cmd, args) {
  let res;
  try {
    res = await chrome.tabs.sendMessage(tabId, { ah: 'neis-cmd', cmd, args: args || {} }, { frameId: 0 });
  } catch (e) {
    throw new PanelError('no_content', '나이스 페이지와 연결하지 못했습니다. 나이스 페이지를 새로고침(F5)한 뒤 다시 시도하세요.');
  }
  if (!res) throw new PanelError('no_content', '나이스 페이지에서 응답이 없습니다. 페이지를 새로고침(F5)한 뒤 다시 시도하세요.');
  if (!res.ok) throw new PanelError(res.error.code, res.error.message, res.error.data);
  return res.result;
}
function cmd(name, args) {
  const tabId = S.session ? S.session.tabId : S.conn.tabId;
  if (tabId == null) return Promise.reject(new PanelError('no_tab', `나이스 화면을 찾지 못했습니다. ${NEIS_GUIDE}`));
  return sendToTab(tabId, name, args);
}

async function detect() {
  let tabs = [];
  try { tabs = await chrome.tabs.query({ url: NEIS_URLS }); } catch (e) { tabs = []; }
  let cur = null;
  try { [cur] = await chrome.tabs.query({ active: true, lastFocusedWindow: true }); } catch (e) { /* 없음 */ }
  tabs.sort((a, b) => {
    const sa = (cur && a.id === cur.id ? 4 : 0) + (a.active ? 2 : 0);
    const sb = (cur && b.id === cur.id ? 4 : 0) + (b.active ? 2 : 0);
    return sb - sa || (b.lastAccessed || 0) - (a.lastAccessed || 0);
  });
  if (S.session) tabs.sort((a, b) => (b.id === S.session.tabId) - (a.id === S.session.tabId));
  let next = { state: tabs.length ? 'noscreen' : 'notab' };
  for (const t of tabs.slice(0, 5)) {
    try {
      const info = await sendToTab(t.id, 'detect');
      if (info.neis) { next = { state: 'ok', tabId: t.id, info }; break; }
    } catch (e) {
      if (next.state !== 'noscreen') next = { state: 'noscript' };
    }
  }
  const changed = JSON.stringify(next) !== JSON.stringify(S.conn);
  S.conn = next;
  if (changed) render();
}

chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.ah !== 'neis-event') return;
  const ev = msg.event || {};
  if (ev.type === 'log') {
    S.logs.push({ at: ev.at || Date.now(), level: ev.level, msg: ev.msg });
    if (S.logs.length > 200) S.logs.splice(0, S.logs.length - 200);
    renderLog();
  } else if (ev.type === 'step' && S.session) {
    S.session.steps[ev.step] = ev.state;
    render();
  }
});

// ---------- 입력 세션 ----------
function stale(run, i) { return !S.session || S.session.runId !== run || (i != null && S.session.idx !== i); }

async function startDate(date) {
  if (S.conn.state !== 'ok') { toast(NEIS_GUIDE, true); return; }
  if (!S.roster || !S.roster.students.length) { toast('먼저 [명단] 탭에서 나이스 명단을 불러오세요.', true); switchTab('roster'); return; }
  const recs = pendingRecords().filter((r) => r.date === date);
  if (!recs.length) { toast('이 날짜에 입력할 기록이 없습니다.'); return; }
  const run = ++runCounter;
  // 같은 학생·같은 날짜 기록이 2건 이상이면 자동 입력하지 않음 (선생님이 나이스에 직접 입력)
  const byNo = new Map();
  for (const r of recs) { if (!byNo.has(r.no)) byNo.set(r.no, []); byNo.get(r.no).push(r); }
  S.session = {
    runId: run, date, tabId: S.conn.tabId, idx: 0, phase: 'moving', steps: {}, error: null,
    ctx: { date, grade: S.roster.grade || null, classNo: S.roster.classNo || null },
    items: [...byNo.values()].map((g) => ({
      ids: g.map((r) => r.id), recs: g, rec: g[0], name: nameOf(g[0].no), manual: g.length > 1,
      status: g.length > 1 ? 'manual' : 'wait', applied: false, warnings: [],
    })),
  };
  render();
  try {
    await cmd('setDate', { date });
  } catch (e) {
    if (stale(run)) return;
    Object.assign(S.session, { phase: 'dateError', error: e.message });
    render();
    return;
  }
  if (stale(run)) return;
  detect();
  runStudent(0);
}

async function runStudent(i) {
  const s = S.session;
  const run = s.runId;
  const it = s.items[i];
  s.idx = i; s.error = null; s.errorCode = null; s.errorData = null; s.steps = {}; s.alreadyDiffs = null;
  if (it.manual) { s.phase = 'manual'; render(); return; }
  it.status = 'current'; it.warnings = [];
  const r = it.rec;
  const expectedGb = chulgyulGb(r.div, r.kind);
  try {
    if (!it.name) throw new PanelError('no_name', `${r.no}번 학생이 명단에 없습니다. [명단] 탭에서 다시 불러오세요.`);
    if (!it.applied) {
      s.phase = 'working'; render();
      const prep = await cmd('prepareStudent', {
        ctx: s.ctx, no: r.no, name: it.name, divNeis: DIVS[r.div].neis, sortNeis: KINDS[r.kind].neis,
        divKo: DIVS[r.div].ko, kindKo: KINDS[r.kind].ko, reason: r.reason || '', expectedGb,
      });
      if (stale(run, i)) return;
      it.totMax = prep.totMax;
      s.phase = 'waitApply'; render();
      const w = await cmd('waitPopupClosed', { ctx: s.ctx, no: r.no, name: it.name, expectedGb, timeout: 15 * 60 * 1000 });
      if (stale(run, i)) return;
      if (w.status === 'cancelled') {
        it.status = 'cancelled'; s.phase = 'cancelled'; s.steps[4] = 'error'; render();
        return;
      }
      if (w.status === 'mismatch') {
        throw new PanelError('mismatch', `나이스 표에 '${w.gb}'(으)로 적용되었습니다. 기록은 '${expectedGb}'입니다. 나이스 표를 직접 확인해 고쳐 주세요.`);
      }
      it.applied = true;
      s.steps[4] = 'done';
    }
    s.phase = 'marking'; render();
    const expected = expectedNeisMarks(r, it.totMax || (S.data && S.data.settings.periodsPerDay) || 7);
    const res = await cmd('markPeriods', { ctx: s.ctx, no: r.no, name: it.name, kind: r.kind, period: r.period, periods: r.periods, expected, reason: r.reason || '' });
    if (stale(run, i)) return;
    await cmd('resetCombo').catch((e) => { it.warnings.push(e.message); });
    if (stale(run, i)) return;
    it.warnings = it.warnings.concat(res.warnings || []);
    if (res.ok) {
      it.status = 'applied'; s.phase = 'checked';
    } else {
      it.status = 'error'; s.phase = 'error'; s.error = res.diffs.join(' ');
    }
    render();
  } catch (e) {
    if (stale(run, i) || e.code === 'aborted') return;
    it.status = 'error';
    let msg = e.message;
    if (e.code === 'name_mismatch' && e.data) msg += ` (명단: ${e.data.expected}, 나이스: ${e.data.actual})`;
    if (e.code === 'already' && e.data) {
      s.alreadyDiffs = marksDiff(r, e.data.totMax, e.data.marks);
      msg += ` 나이스 표시: ${describeMarks(e.data.marks, e.data.totMax)}.`;
      if (!e.data.clean) msg += ' 이 행은 아직 저장되지 않은 변경이 있습니다.';
    }
    Object.assign(s, { phase: 'error', error: msg, errorCode: e.code, errorData: e.data || null });
    const cur = Object.keys(s.steps).find((k) => s.steps[k] === 'current');
    if (cur) s.steps[cur] = 'error';
    render();
  }
}

// 나이스 표시 요약: "조회, 1교시, 2교시, 종례"
function describeMarks(m, totMax) {
  const out = [];
  if (m.jo === '/') out.push('조회');
  for (let i = 1; i <= (totMax || Object.keys(m.gyo).length); i++) if (m.gyo[i] === '/') out.push(`${i}교시`);
  if (m.jong === '/') out.push('종례');
  return out.length ? out.join(', ') : '교시 표시 없음';
}
// '입력된 것으로 처리' 판정: 구분 + 교시까지 비교. 빈 배열이면 같음.
function marksDiff(rec, totMax, m) {
  const exp = expectedNeisMarks(rec, totMax || 7);
  const diffs = [];
  if (m.chulgyulGb !== exp.chulgyulGb) diffs.push(`출결 구분: 나이스 '${m.chulgyulGb}', 기록 '${exp.chulgyulGb}'`);
  if (rec.kind === 'result') {
    const miss = (rec.periods || []).filter((p) => m.gyo[p] !== '/');
    if (miss.length) diffs.push(`${miss.join(', ')}교시가 나이스에 표시되어 있지 않습니다`);
  } else {
    const a = describeMarks(m, totMax), e = describeMarks(exp, totMax);
    if (a !== e) diffs.push(`교시: 나이스 ${a} / 기록 ${e}`);
  }
  return diffs;
}

async function markManual() {
  const s = S.session;
  const it = s.items[s.idx];
  await markDone(it.ids);
  it.status = 'done';
  toast(`${it.rec.no}번 기록 ${it.ids.length}건을 입력 완료로 표시했습니다.`);
  goNext();
}

async function gotoSessionDate() {
  const s = S.session;
  if (!s) return;
  const run = s.runId;
  try {
    await cmd('setDate', { date: s.date });
  } catch (e) { toast(e.message, true); return; }
  await detect();
  if (stale(run)) return;
  toast(`${formatDateKo(s.date)}로 이동했습니다.`);
  if (['error', 'cancelled'].includes(s.phase)) { s.runId = ++runCounter; runStudent(s.idx); }
  else if (s.phase === 'saveError') { s.runId = ++runCounter; finishDate(); }
  else render();
}

function goNext() {
  const s = S.session;
  if (s.idx + 1 < s.items.length) runStudent(s.idx + 1);
  else finishDate();
}

async function skipStudent() {
  const s = S.session;
  const it = s.items[s.idx];
  const wasWaiting = ['working', 'waitApply', 'marking'].includes(s.phase);
  s.runId = ++runCounter; // 진행 중이던 응답 무시
  if (wasWaiting) {
    try { await cmd('abort'); } catch (e) { /* 무시 */ }
  }
  if (it.status !== 'applied' && it.status !== 'done') it.status = 'skipped';
  if (s.phase === 'waitApply') toast('나이스에 팝업이 열려 있으면 [닫기]를 눌러 주세요.');
  if (it.applied) toast('이 학생은 이미 표에 적용되었습니다. 저장하면 나이스에 기록되지만 앱에는 입력 완료로 표시되지 않습니다.', true);
  goNext();
}

async function finishDate() {
  const s = S.session;
  const run = s.runId;
  const toSave = s.items.filter((it) => it.status === 'applied' || it.status === 'already');
  if (!toSave.length) { s.phase = 'finishedNone'; render(); return; }
  s.toSaveCount = toSave.length;
  s.phase = 'waitSave'; s.error = null; render();
  try {
    await cmd('waitSaved', {
      ctx: s.ctx, timeout: 60 * 60 * 1000,
      students: toSave.map((it) => ({ no: it.rec.no, name: it.name, expectedGb: chulgyulGb(it.rec.div, it.rec.kind) })),
    });
  } catch (e) {
    if (stale(run) || e.code === 'aborted') return;
    Object.assign(s, { phase: 'saveError', error: e.message, errorCode: e.code });
    render();
    return;
  }
  if (stale(run)) return;
  await markDone(toSave.flatMap((it) => it.ids));
  toSave.forEach((it) => { it.status = 'done'; });
  s.phase = 'saved';
  s.savedCount = toSave.length;
  render();
}

// 나이스 입력 완료 표시 (contract 5·6절):
// 드라이브를 먼저 받아 shared mergeData 로 병합한 뒤 neis.done / doneAt / updatedAt 만 바꾼다.
// 기록 updatedAt 은 올리지 않는다 (다른 기기의 본문 수정·삭제를 덮지 않도록).
async function markDone(ids) {
  let token = null, fileId = null;
  if (S.drive.connected && drive.hasClientId()) {
    try {
      token = await drive.getToken(false);
      const d = await drive.download(token);
      fileId = d.fileId;
      if (d.data) S.data = mergeData(S.data, d.data);
    } catch (e) {
      token = null;
      toast('드라이브를 받지 못해 이 PC에 먼저 표시했습니다. 다음 동기화 때 올라갑니다.', true);
    }
  }
  const now = new Date().toISOString();
  const set = new Set(ids);
  for (const r of S.data.records) {
    if (set.has(r.id)) r.neis = { ...(r.neis || {}), done: true, doneAt: now, updatedAt: now };
  }
  S.data.updatedAt = now;
  await store.saveData(S.data);
  if (token) {
    try {
      await drive.upload(token, fileId, S.data);
      S.drive = { connected: true, lastSyncAt: new Date().toISOString() };
      await store.saveDriveState(S.drive);
    } catch (e) { scheduleSync(); }
  } else {
    scheduleSync();
  }
}

async function stopSession() {
  if (!S.session) return;
  const busy = ['moving', 'working', 'waitApply', 'marking', 'waitSave'].includes(S.session.phase);
  S.session.runId = ++runCounter;
  if (busy) { try { await cmd('abort'); } catch (e) { /* 무시 */ } }
  S.session = null;
  render();
}

// ---------- 명단 ----------
async function confirmRoster() {
  const g = Number($('rcGrade').value), c = Number($('rcClass').value);
  if (!(g >= 1 && g <= 6) || !(c >= 1 && c <= 30)) { toast('학년과 반을 숫자로 입력하세요.', true); return; }
  S.roster = { ...S.rosterConfirm, grade: g, classNo: c };
  S.rosterConfirm = null;
  await store.saveRoster(S.roster);
  toast(`${g}학년 ${c}반 명단 ${S.roster.students.length}명을 저장했습니다.`);
  render();
}

async function importRoster() {
  if (S.conn.state !== 'ok') { toast(NEIS_GUIDE, true); return; }
  S.rosterBusy = true; render();
  try {
    const r = await cmd('readRoster');
    const year = (S.data && S.data.settings.schoolYear) || (r.date ? Number(r.date.slice(0, 4)) : new Date().getFullYear());
    const roster = { schoolYear: year, grade: r.grade, classNo: r.classNo, students: r.students, importedAt: new Date().toISOString(), classSource: 'neis' };
    if (r.grade == null || r.classNo == null) {
      // 나이스 화면에서 학년·반을 읽지 못함 -> 선생님이 확인
      S.rosterConfirm = { ...roster, classSource: 'teacher',
        grade: (S.data && S.data.settings.grade) || '', classNo: (S.data && S.data.settings.classNo) || '' };
      return;
    }
    S.roster = roster;
    await store.saveRoster(S.roster);
    toast(`${r.students.length}명의 명단을 불러왔습니다.`);
  } catch (e) {
    toast(e.message, true);
  } finally {
    S.rosterBusy = false; render();
  }
}

// ---------- 동기화 ----------
let syncTimer = null;
function scheduleSync(ms) {
  if (!S.drive.connected || !drive.hasClientId()) return;
  clearTimeout(syncTimer);
  syncTimer = setTimeout(() => syncNow(false, true), ms == null ? 2000 : ms);
}
async function syncNow(interactive, quiet) {
  if (!drive.hasClientId()) { if (!quiet) { toast('구글 연결이 설정되지 않았습니다. [설정] 탭을 확인하세요.', true); switchTab('settings'); } return; }
  if (!S.drive.connected && !interactive) { if (!quiet) { toast('먼저 [설정] 탭에서 구글 드라이브를 연결하세요.'); switchTab('settings'); } return; }
  if (S.syncing) return;
  S.syncing = true; render();
  try {
    const token = await drive.getToken(interactive);
    const { fileId, data: remote } = await drive.download(token);
    if (!S.data && !remote) {
      S.drive = { connected: true, lastSyncAt: new Date().toISOString() };
    } else {
      const merged = mergeData(S.data, remote);
      await drive.upload(token, fileId, merged);
      S.data = merged;
      await store.saveData(merged);
      S.drive = { connected: true, lastSyncAt: new Date().toISOString() };
    }
    await store.saveDriveState(S.drive);
    if (!quiet) toast('동기화했습니다.');
  } catch (e) {
    if (!quiet || e.code === 'auth') toast(e.message, true);
  } finally {
    S.syncing = false; render();
  }
}
async function connectDrive() {
  S.drive.connected = true;
  await syncNow(true);
  if (!S.drive.lastSyncAt) { S.drive.connected = false; }
  await store.saveDriveState(S.drive);
  render();
}
async function disconnectDrive() {
  await drive.forgetToken();
  S.drive = { connected: false, lastSyncAt: null };
  await store.saveDriveState(S.drive);
  toast('구글 드라이브 연결을 해제했습니다. 이 PC의 기록은 남아 있습니다.');
  render();
}

// ---------- 백업 ----------
async function importBackup(file) {
  try {
    const obj = store.parseBackup(await file.text());
    S.data = mergeData(S.data, obj);
    await store.saveData(S.data);
    toast(`기록 ${obj.records.length}건을 가져왔습니다.`);
    scheduleSync();
  } catch (e) {
    toast(`가져오지 못했습니다. ${e.message}`, true);
  }
  render();
}
function exportBackup() {
  if (!S.data) { toast('내보낼 기록이 없습니다.'); return; }
  const blob = new Blob([JSON.stringify(S.data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  const d = new Date();
  a.href = URL.createObjectURL(blob);
  a.download = `attendance-data-${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}.json`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

// ---------- 화면 ----------
function switchTab(tab) { S.tab = tab; render(); }

function renderConn() {
  const c = S.conn;
  if (c.state === 'ok') {
    const cls = c.info.cls;
    const d = c.info.gridYmd || c.info.ymd;
    const where = [cls ? `${cls.grade}학년 ${cls.classNo}반` : '', d ? `${formatDateKo(d)} 화면` : ''].filter(Boolean).join(' · ');
    return `<section class="card conn is-ok" data-testid="conn"><span class="conn-dot"></span>
      <div class="conn-main"><div class="conn-title">나이스 화면 감지됨</div><div class="conn-meta num">${esc(where)}</div></div>
      <span class="badge badge-done">연결됨</span></section>`;
  }
  const extra = c.state === 'noscript'
    ? '화면을 연 뒤에도 이 안내가 보이면 나이스 페이지를 새로고침(F5)하세요.'
    : c.state === 'checking' ? '나이스 화면을 찾는 중입니다.' : '화면이 열리면 자동으로 연결됩니다.';
  return `<div class="alert alert-info" data-testid="conn">${icon('i-info')}<div class="alert-body">
    <strong class="alert-title">나이스 화면이 감지되지 않았습니다</strong>${esc(NEIS_GUIDE)}<div class="small muted">${esc(extra)}</div></div></div>`;
}

// 입력 중인 날짜와 나이스 화면 날짜가 다르면 빨간 경고
function dateMismatch() {
  const s = S.session;
  if (!s || S.conn.state !== 'ok' || ['saved', 'finishedNone', 'moving'].includes(s.phase)) return '';
  const d = S.conn.info.gridYmd || S.conn.info.ymd;
  if (!d || (d === s.date && (S.conn.info.ymd || d) === s.date)) return '';
  return `<div class="alert alert-block" role="alert" data-testid="date-mismatch">${icon('i-alert')}<div class="alert-body"><strong class="alert-title">나이스 날짜가 다릅니다</strong>
    나이스 화면은 ${esc(formatDateKo(d))}, 입력 중인 날짜는 ${esc(formatDateKo(s.date))}입니다. 이대로는 입력하지 않습니다.
    <div class="alert-actions"><button class="btn btn-secondary btn-sm" data-act="gotoDate">이 날짜로 이동</button></div></div></div>`;
}

function rosterMismatch() {
  if (!S.roster || S.conn.state !== 'ok' || !S.conn.info.cls) return '';
  const h = S.conn.info.cls;
  if (S.roster.grade && (S.roster.grade !== h.grade || S.roster.classNo !== h.classNo)) {
    return `<div class="alert alert-block" role="alert">${icon('i-alert')}<div class="alert-body"><strong class="alert-title">반이 다릅니다</strong>
      저장된 명단은 ${S.roster.grade}학년 ${S.roster.classNo}반, 나이스 화면은 ${h.grade}학년 ${h.classNo}반입니다. [명단] 탭에서 다시 불러오세요.</div></div>`;
  }
  return '';
}

function renderPendingList() {
  const recs = pendingRecords();
  if (!S.data) {
    return `<div class="card"><div class="empty">${icon('i-list')}<div class="empty-title">가져온 기록이 없습니다</div>
      <div class="empty-text">[설정]에서 구글 드라이브를 연결하거나 앱에서 내보낸 백업 파일을 가져오세요.</div>
      <button class="btn btn-secondary btn-sm" data-act="tab" data-tab="settings">설정으로 가기</button></div></div>`;
  }
  if (!recs.length) {
    return `<div class="card"><div class="empty">${icon('i-check')}<div class="empty-title">나이스에 입력할 기록이 없습니다</div>
      <div class="empty-text">모든 기록이 입력 완료 상태입니다.</div></div></div>`;
  }
  const canStart = S.conn.state === 'ok';
  const dates = pendingDates();
  const groups = dates.map((d, gi) => {
    const items = recs.filter((r) => r.date === d);
    const rows = items.map((r) => {
      const nm = nameOf(r.no);
      return `<li class="list-row"><span class="list-no">${r.no}</span><div class="list-main">
        <div class="list-title">${esc(nm || '이름 없음')} · ${esc(recordLine(r))}</div>
        ${r.reason ? `<div class="list-meta">${esc(r.reason)}</div>` : ''}</div>
        <span class="badge badge-neis-wait">대기</span></li>`;
    }).join('');
    return `<div class="list-group-head"><span>${esc(formatDateKo(d))} <span class="num">· ${items.length}건</span></span>
      <button class="btn ${gi === 0 ? 'btn-primary' : 'btn-secondary'} btn-sm" data-act="start" data-date="${d}" ${canStart ? '' : 'disabled'}>이 날짜 입력 시작</button></div>
      <ul class="list">${rows}</ul>`;
  }).join('');
  return `<section class="card card-flush" data-testid="pending"><div class="card-head"><h2 class="card-title">나이스 미입력 기록</h2>
    <span class="small muted num">${recs.length}건</span></div>${groups}</section>
    <div class="alert alert-info">${icon('i-info')}<div class="alert-body">날짜 순서대로 입력하세요. [저장]은 날짜마다 선생님이 나이스에서 직접 누릅니다.</div></div>`;
}

const STATUS_BADGE = {
  wait: ['badge-neis-wait', '대기'], current: ['badge-info', '진행 중'], applied: ['badge-done', '적용됨'],
  already: ['badge-done', '이미 입력'], skipped: ['', '건너뜀'], cancelled: ['', '취소됨'], error: ['badge-missing', '확인 필요'],
  done: ['badge-neis-done', '입력 완료'], manual: ['badge-missing', '직접 입력'],
};

function stepClass(s, n) {
  const st = s.steps[n];
  if (st === 'done') return 'is-done';
  if (st === 'error') return 'is-error';
  if (st === 'current') return 'is-current';
  if (n === 4 && s.phase === 'waitApply') return 'is-current';
  return '';
}

function renderSession() {
  const s = S.session;
  const n = s.items.length;
  const finished = s.items.filter((it) => ['applied', 'already', 'skipped', 'done'].includes(it.status)).length;
  const it = s.items[s.idx];
  const r = it.rec;
  const savePhase = ['waitSave', 'saved', 'finishedNone', 'saveError'].includes(s.phase);
  let html = `<section class="card stack-sm" data-testid="progress"><div class="row-between">
    <span class="strong">${esc(formatDateKo(s.date))} 입력 중</span>
    <span class="row"><span class="small muted num">${savePhase ? n : Math.min(s.idx + 1, n)} / ${n}명</span>
    <button class="btn btn-ghost btn-sm" data-act="stop">그만두기</button></span></div>
    <div class="progress" role="progressbar" aria-valuenow="${finished}" aria-valuemin="0" aria-valuemax="${n}"><span style="width:${Math.round((finished / n) * 100)}%"></span></div></section>`;

  if (savePhase) {
    if (s.phase === 'waitSave') {
      html += `<div class="callout" data-testid="callout" data-phase="waitSave"><div class="callout-who">${esc(formatDateKo(s.date))} 학생 확인을 마쳤습니다</div>
        <div class="callout-what">나이스 표에 적용한 내용은 아직 저장되지 않았습니다.</div>
        <div class="callout-do">[저장]을 눌러 주세요 · 나이스의 ${kbd('저장')} 버튼</div></div>`;
    } else if (s.phase === 'saved') {
      html += `<div class="callout is-done" data-testid="callout" data-phase="saved"><div class="callout-who">저장을 확인했습니다</div>
        <div class="callout-what">${s.savedCount}건을 나이스 입력 완료로 표시했습니다.</div>
        <div class="callout-do">${pendingDates().length ? '다음 날짜를 입력할 수 있습니다.' : '남은 미입력 기록이 없습니다.'}</div></div>`;
    } else if (s.phase === 'finishedNone') {
      html += `<div class="callout" data-testid="callout" data-phase="finishedNone"><div class="callout-who">입력한 학생이 없습니다</div>
        <div class="callout-what">자동으로 입력한 학생이 없어 저장을 기다리지 않습니다. 나이스에서 직접 입력한 학생이 있다면 나이스 [저장]을 눌렀는지 확인하세요.</div></div>`;
    } else {
      html += `<div class="alert alert-block" role="alert" data-testid="error">${icon('i-alert')}<div class="alert-body"><strong class="alert-title">저장을 확인하지 못했습니다</strong>${esc(s.error)}
        ${s.errorCode === 'date_changed' ? '<div class="alert-actions"><button class="btn btn-secondary btn-sm" data-act="gotoDate">이 날짜로 이동</button></div>' : ''}</div></div>`;
    }
  } else if (s.phase === 'dateError') {
    html += `<div class="alert alert-block" role="alert" data-testid="error">${icon('i-alert')}<div class="alert-body"><strong class="alert-title">날짜를 바꾸지 못했습니다</strong>${esc(s.error)}</div></div>`;
  } else {
    const who = `${r.no}번 ${it.name || '(이름 없음)'}`;
    const what = it.manual ? it.recs.map(recordLine).join(' + ') : `${recordLine(r)}${r.reason ? ` · ${r.reason}` : ''}`;
    let doText = '';
    if (s.phase === 'moving') doText = '나이스 날짜를 바꾸는 중입니다';
    else if (s.phase === 'working') doText = '나이스 화면을 채우는 중입니다. 잠시 기다려 주세요';
    else if (s.phase === 'waitApply') doText = `팝업 내용을 확인한 뒤 ${kbd('적용')}을 누르세요`;
    else if (s.phase === 'marking') doText = r.kind === 'absent' ? '결석은 교시를 누르지 않습니다. 표를 확인하는 중입니다' : '교시를 표시하고 확인하는 중입니다';
    else if (s.phase === 'checked') doText = `표에 반영되었습니다. ${kbd('다음 학생')}을 누르세요`;
    else if (s.phase === 'cancelled') doText = '팝업을 닫아 입력하지 않았습니다 (취소됨)';
    else if (s.phase === 'manual') doText = `같은 날 기록이 ${it.recs.length}건입니다. 나이스에서 직접 입력한 뒤 ${kbd('입력 완료로 표시')}를 누르세요`;
    html += `<div class="callout" data-testid="callout" data-phase="${s.phase}"><div class="callout-who">${esc(who)}</div>
      <div class="callout-what">${esc(what)}</div>${doText ? `<div class="callout-do">${doText}</div>` : ''}</div>`;
    if (s.phase === 'error') {
      let extra = '';
      if (s.errorCode && /^popup/.test(s.errorCode)) extra = '<div class="small">나이스에 팝업이 열려 있으면 [닫기]를 누른 뒤 [다시 시도]하세요.</div>';
      let actions = '';
      if (s.errorCode === 'already' && s.alreadyDiffs) {
        actions = s.alreadyDiffs.length
          ? `<div class="small">기록과 다른 점 (덮어쓰지 않았습니다. 나이스에서 직접 고친 뒤 [건너뛰기]하세요):</div><ul class="warn-list" data-testid="already-diffs">${s.alreadyDiffs.map((d) => `<li>${esc(d)}</li>`).join('')}</ul>`
          : '<div class="alert-actions"><button class="btn btn-secondary btn-sm" data-act="already">입력된 것으로 처리</button></div>';
      }
      if (s.errorCode === 'date_changed') actions += '<div class="alert-actions"><button class="btn btn-secondary btn-sm" data-act="gotoDate">이 날짜로 이동</button></div>';
      html += `<div class="alert alert-block" role="alert" data-testid="error">${icon('i-alert')}<div class="alert-body"><strong class="alert-title">멈췄습니다</strong>${esc(s.error)}${extra}${actions}</div></div>`;
    }
    if (it.warnings.length) {
      html += `<div class="alert alert-info" data-testid="warnings">${icon('i-info')}<div class="alert-body"><strong>표시가 예상과 조금 다릅니다. 나이스 표를 확인하세요.</strong>
        <ul class="warn-list">${it.warnings.map((w) => `<li>${esc(w)}</li>`).join('')}</ul></div></div>`;
    }
    html += `<section class="card"><ol class="steps" data-testid="steps">${STEP_LABELS.map((t, i) =>
      `<li class="step ${stepClass(s, i + 1)}"><span class="step-mark">${i + 1}</span><span class="step-text">${esc(t)}</span></li>`).join('')}</ol></section>`;
  }

  html += `<section class="card card-flush"><div class="list-group-head"><span>${esc(formatDateKo(s.date))}</span><span class="num">${n}건</span></div>
    <ul class="list" data-testid="session-list">${s.items.map((x, i) => {
      const [cls, label] = STATUS_BADGE[x.status] || STATUS_BADGE.wait;
      const cur = i === s.idx && !savePhase ? ' is-current' : '';
      const done = ['done', 'applied', 'already'].includes(x.status) ? ' is-done' : '';
      return `<li class="list-row${cur}${done}" data-no="${x.rec.no}"><span class="list-no">${x.rec.no}</span>
        <div class="list-main"><div class="list-title">${esc(x.name || '이름 없음')} · ${esc(x.recs.map(recordLine).join(' + '))}</div></div>
        <span class="badge ${cls}" data-status="${x.status}">${label}</span></li>`;
    }).join('')}</ul></section>`;
  html += `<div class="alert alert-info">${icon('i-info')}<div class="alert-body">[저장]은 날짜별로 선생님이 직접 누르세요. 확장 프로그램은 [적용]과 [저장]을 누르지 않습니다.</div></div>`;
  return html;
}

function footerFor() {
  const s = S.session;
  if (S.tab !== 'neis' || !s) return '';
  const b = (act, label, cls, disabled) => `<button class="btn ${cls}" data-act="${act}" ${disabled ? 'disabled' : ''}>${label}</button>`;
  switch (s.phase) {
    case 'moving': case 'working': case 'waitApply': case 'marking':
      return b('skip', '건너뛰기', 'btn-secondary') + b('next', '다음 학생', 'btn-primary', true);
    case 'checked':
      return b('skip', '건너뛰기', 'btn-secondary', true) + b('next', '다음 학생', 'btn-primary');
    case 'manual':
      return b('skip', '건너뛰기', 'btn-secondary') + b('manualDone', '입력 완료로 표시', 'btn-primary');
    case 'cancelled': case 'error':
      return b('skip', '건너뛰기', 'btn-secondary') + b('retry', '다시 시도', 'btn-primary');
    case 'dateError':
      return b('stop', '그만두기', 'btn-secondary') + b('restart', '다시 시도', 'btn-primary');
    case 'waitSave':
      return b('stop', '그만두기', 'btn-secondary') + b('none', '저장 기다리는 중', 'btn-primary', true);
    case 'saveError':
      return b('stop', '그만두기', 'btn-secondary') + b(s.errorCode === 'reverted' ? 'restart' : 'recheck', s.errorCode === 'reverted' ? '이 날짜 다시 입력' : '다시 확인', 'btn-primary');
    case 'saved': case 'finishedNone': {
      const next = pendingDates()[0];
      return b('stop', '목록으로', 'btn-secondary') + `<button class="btn btn-primary" data-act="start" data-date="${next || ''}" ${next ? '' : 'disabled'}>다음 날짜 입력</button>`;
    }
    default: return '';
  }
}

function renderNeis() {
  let html = renderConn() + rosterMismatch() + dateMismatch();
  if (!S.session && S.data && (!S.roster || !S.roster.students.length)) {
    html += `<div class="alert alert-info">${icon('i-user')}<div class="alert-body">학생 이름을 표시하려면 [명단] 탭에서 나이스 명단을 먼저 불러오세요.
      <div class="alert-actions"><button class="btn btn-secondary btn-sm" data-act="tab" data-tab="roster">명단 불러오기</button></div></div></div>`;
  }
  html += S.session ? renderSession() : renderPendingList();
  html += `<details class="log" ${S.logOpen ? 'open' : ''} id="logBox"><summary>작업 기록 보기</summary><ul class="log-lines" id="logLines"></ul></details>`;
  return html;
}

function renderRoster() {
  const r = S.roster;
  const canRead = S.conn.state === 'ok' && !S.session;
  let html = `<section class="card stack-sm"><h2 class="card-title">나이스 명단</h2>
    <p class="small muted" style="margin:0">나이스 출결 표에서 번호와 이름만 읽어 이 PC에만 저장합니다. 구글 드라이브에는 올리지 않습니다.</p>
    <button class="btn btn-primary btn-block" data-act="roster" ${canRead && !S.rosterBusy ? '' : 'disabled'}>${S.rosterBusy ? '불러오는 중' : '나이스에서 명단 불러오기'}</button>
    ${S.conn.state !== 'ok' ? `<div class="small muted">${esc(NEIS_GUIDE)}</div>` : ''}</section>`;
  if (S.rosterConfirm) {
    const rc = S.rosterConfirm;
    html += `<section class="card stack-sm" data-testid="roster-confirm"><h2 class="card-title">학년·반을 확인해 주세요</h2>
      <p class="small" style="margin:0">나이스 화면에서 학년·반을 읽지 못했습니다. 지금 나이스에 열려 있는 반이 맞는지 확인한 뒤 저장하세요. (${rc.students.length}명)</p>
      <div class="field-row"><input class="input num" id="rcGrade" inputmode="numeric" aria-label="학년" value="${esc(rc.grade)}"><span class="small" style="align-self:center">학년</span>
      <input class="input num" id="rcClass" inputmode="numeric" aria-label="반" value="${esc(rc.classNo)}"><span class="small" style="align-self:center">반</span></div>
      <div class="btn-row"><button class="btn btn-primary btn-sm" data-act="confirmRoster">이 반이 맞습니다</button><button class="btn btn-secondary btn-sm" data-act="cancelRoster">취소</button></div></section>`;
  }
  if (r && r.students.length) {
    html += `<section class="card card-flush" data-testid="roster"><div class="card-head"><h2 class="card-title">${r.grade ? `${r.grade}학년 ${r.classNo}반` : '명단'} · <span class="num">${r.students.length}명</span></h2>
      <span class="tiny muted num">${esc(fmtTime(r.importedAt))} 불러옴</span></div>
      <ul class="list roster-grid">${r.students.map((s) => `<li class="list-row"><span class="list-no">${s.no}</span><div class="list-main"><div class="list-title">${esc(s.name)}</div></div></li>`).join('')}</ul></section>
      <button class="btn btn-danger-outline btn-sm" data-act="clearRoster">이 PC에서 명단 지우기</button>`;
  } else {
    html += `<div class="card"><div class="empty">${icon('i-user')}<div class="empty-title">저장된 명단이 없습니다</div>
      <div class="empty-text">나이스 일일출결관리(담임용) 화면을 연 뒤 위 버튼을 누르세요.</div></div></div>`;
  }
  return html;
}

function renderSettings() {
  const hasId = drive.hasClientId();
  const recs = S.data ? S.data.records : [];
  const pend = pendingRecords().length;
  let g = `<section class="card stack-sm"><h2 class="card-title">구글 드라이브 연결</h2>`;
  if (!hasId) {
    g += `<div class="alert alert-info">${icon('i-info')}<div class="alert-body">구글 연결을 쓰려면 확장 폴더의 <b>config.js</b>에 GOOGLE_CLIENT_ID를 넣어야 합니다. 설정 전에는 아래 백업 파일로 기록을 가져올 수 있습니다.</div></div>`;
  } else {
    g += `<div class="small">${S.drive.connected ? `연결됨${S.drive.lastSyncAt ? ` · 마지막 동기화 ${esc(fmtTime(S.drive.lastSyncAt))}` : ''}` : '연결되지 않음'}</div>
      <div class="btn-row">${S.drive.connected
        ? `<button class="btn btn-primary btn-sm" data-act="sync" ${S.syncing ? 'disabled' : ''}>${S.syncing ? '동기화 중' : '지금 동기화'}</button><button class="btn btn-secondary btn-sm" data-act="disconnect">연결 해제</button>`
        : `<button class="btn btn-primary btn-sm" data-act="connect" ${S.syncing ? 'disabled' : ''}>구글 연결</button>`}</div>`;
  }
  g += `<div class="field"><label class="label" for="redir">리디렉션 URI (구글 클라우드 설정에 붙여넣기)</label>
    <div class="field-row"><input class="input num" id="redir" readonly value="${esc(drive.redirectUrl())}"><button class="btn btn-secondary btn-sm" data-act="copyRedir">복사</button></div></div></section>`;
  const b = `<section class="card stack-sm"><h2 class="card-title">백업 파일</h2>
    <p class="small muted" style="margin:0">앱에서 내보낸 JSON 파일을 가져오면 이 PC의 기록과 합칩니다. 같은 기록은 더 최근에 고친 쪽을 남깁니다.</p>
    <div class="small num" data-testid="data-summary">기록 ${recs.length}건 · 나이스 미입력 ${pend}건</div>
    <div class="btn-row"><button class="btn btn-secondary btn-sm" data-act="import">백업 파일 가져오기</button>
    <button class="btn btn-secondary btn-sm" data-act="export" ${S.data ? '' : 'disabled'}>내보내기</button></div></section>`;
  return g + b;
}

function renderLog() {
  const ul = $('logLines');
  if (!ul) return;
  ul.innerHTML = S.logs.length
    ? S.logs.slice(-80).map((l) => {
      const d = new Date(l.at);
      const t = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
      return `<li class="${l.level === 'warn' ? 'is-warn' : l.level === 'error' ? 'is-error' : ''}"><span class="num">${t}</span> ${esc(l.msg)}</li>`;
    }).join('')
    : '<li>기록이 없습니다.</li>';
  ul.scrollTop = ul.scrollHeight;
}

function render() {
  document.querySelectorAll('.panel-tab').forEach((t) => t.setAttribute('aria-selected', String(t.dataset.tab === S.tab)));
  const body = $('body');
  const y = body.parentElement.scrollTop;
  body.innerHTML = S.tab === 'neis' ? renderNeis() : S.tab === 'roster' ? renderRoster() : renderSettings();
  const f = footerFor();
  $('footer').innerHTML = f;
  $('footer').hidden = !f;
  $('btnSync').setAttribute('aria-busy', String(S.syncing));
  const lb = $('logBox');
  if (lb) lb.addEventListener('toggle', () => { S.logOpen = lb.open; });
  renderLog();
  body.parentElement.scrollTop = y;
}

// ---------- 이벤트 ----------
document.addEventListener('click', async (e) => {
  const tabBtn = e.target.closest('.panel-tab');
  if (tabBtn) { switchTab(tabBtn.dataset.tab); return; }
  const el = e.target.closest('[data-act]');
  if (!el || el.disabled) return;
  const act = el.dataset.act;
  const s = S.session;
  switch (act) {
    case 'tab': switchTab(el.dataset.tab); break;
    case 'start': if (el.dataset.date) { if (S.session) S.session = null; startDate(el.dataset.date); } break;
    case 'next': if (s && s.phase === 'checked') goNext(); break;
    case 'skip': if (s) skipStudent(); break;
    case 'retry': if (s) { s.runId = ++runCounter; runStudent(s.idx); } break;
    case 'already': if (s) { s.items[s.idx].status = 'already'; s.phase = 'checked'; s.error = null; render(); } break;
    case 'stop': stopSession(); break;
    case 'manualDone': if (s && s.phase === 'manual') markManual(); break;
    case 'gotoDate': gotoSessionDate(); break;
    case 'confirmRoster': confirmRoster(); break;
    case 'cancelRoster': S.rosterConfirm = null; render(); break;
    case 'restart': if (s) { const d = s.date; S.session = null; startDate(d); } break;
    case 'recheck': if (s) { s.runId = ++runCounter; finishDate(); } break;
    case 'roster': importRoster(); break;
    case 'clearRoster': await store.clearRoster(); S.roster = null; toast('이 PC의 명단을 지웠습니다.'); render(); break;
    case 'sync': syncNow(false); break;
    case 'connect': connectDrive(); break;
    case 'disconnect': disconnectDrive(); break;
    case 'copyRedir':
      try { await navigator.clipboard.writeText(drive.redirectUrl()); toast('리디렉션 URI를 복사했습니다.'); }
      catch (err) { $('redir').select(); toast('복사하지 못했습니다. 주소를 직접 선택해 복사하세요.', true); }
      break;
    case 'import': $('importFile').value = ''; $('importFile').click(); break;
    case 'export': exportBackup(); break;
    default: break;
  }
});
$('importFile').addEventListener('change', (e) => { const f = e.target.files[0]; if (f) importBackup(f); });

chrome.tabs.onActivated.addListener(() => detect());
chrome.tabs.onUpdated.addListener((id, info) => { if (info.status === 'complete') detect(); });

// ---------- 시작 ----------
(async function init() {
  [S.data, S.roster, S.drive] = await Promise.all([store.loadData(), store.loadRoster(), store.loadDriveState()]);
  render();
  await detect();
  setInterval(() => { if (!document.hidden) detect(); }, 3000);
  if (S.drive.connected && drive.hasClientId()) syncNow(false, true);
})();
