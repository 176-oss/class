// 출결관리 도우미 - 확장 사이드 패널
import { mergeData, KINDS, DIVS, NEIS_DIVS, orderedNeisDivs, ILL_DOC_TYPES, chulgyulGb, formatDateKo, describeKind, neisBlockReason, createRecord, diffRemoteChanges, compareVersions, makeRoster, hasRoster } from '../shared/model.js';
import { expectedNeisMarks, requiredDocs } from '../shared/rules.js';
import * as store from './store.js';
import * as drive from './drive.js';

const NEIS_URLS = ['https://*.neis.go.kr/*'];
// 새 버전 안내: 출결 기록 웹앱과 같은 폴더의 최신 버전 정보 (spec 14.2)
const APP_BASE = 'https://176-oss.github.io/class/attendance/';
const VERSION_URL = APP_BASE + 'extension-version.json';
const NEIS_GUIDE = '나이스 > 학급담임 > 출결관리 > 일일출결관리(담임용) 화면을 열어 주세요.';

const S = {
  excl: {},
  rosterConfirm: null,
  notice: null,
  tab: 'neis',
  data: null,
  roster: null,
  drive: { connected: false, lastSyncAt: null },
  conn: { state: 'checking' },
  session: null,
  logs: [],
  logOpen: false,
  syncing: false,
  committing: false,
  checking: false,
  remote: { fileId: null, stamp: null, lastCheckAt: null }, // 자동 확인: 드라이브 파일 id, 마지막으로 맞춘 version|modifiedTime
  rosterBusy: false,
  rosterClearAsk: false,
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let runCounter = 0;

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const kbd = (t) => `<span class="kbd">${esc(t)}</span>`;
const icon = (id) => `<svg class="icon" aria-hidden="true"><use href="#${id}"/></svg>`;
const fmtTime = (iso) => {
  if (!iso) return '';
  const d = new Date(iso);
  return `${d.getMonth() + 1}월 ${d.getDate()}일 ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
};
class PanelError extends Error { constructor(code, message, data) { super(message); this.code = code; this.data = data; } }

// ---------- 데이터 ----------
// 이름이 필요한 곳은 모두 이 함수들을 거친다. 이 PC의 나이스 명단(S.roster)이 우선, 없으면 드라이브(앱)에서 온 명단(S.data.roster) 폴백.
const localRosterOn = () => !!(S.roster && S.roster.students && S.roster.students.length);
const driveRosterOn = () => hasRoster(S.data && S.data.roster);
const rosterList = () => (localRosterOn() ? S.roster.students : driveRosterOn() ? S.data.roster.students : []);
const usingFallback = () => !localRosterOn() && driveRosterOn();
const nameOf = (no) => (rosterList().find((s) => Number(s.no) === Number(no)) || {}).name || '';
const ROSTER_LATER_KEY = 'ah.rosterUploadLater';
// 나이스 화면의 학년·반 확인 기준: 나이스 명단의 학년·반, 폴백이면 앱 설정의 학년·반
function classOfRoster() {
  if (localRosterOn()) return { grade: S.roster.grade || null, classNo: S.roster.classNo || null };
  const st = (S.data && S.data.settings) || {};
  return { grade: st.grade || null, classNo: st.classNo || null };
}
function pendingRecords() {
  return (S.data ? S.data.records : []).filter((r) => !(r.neis && r.neis.done))
    .sort((a, b) => (a.date === b.date ? a.no - b.no : a.date < b.date ? -1 : 1));
}
function pendingDates() { return [...new Set(pendingRecords().map((r) => r.date))]; }
// 제외 기록: 기록이 그 뒤 고쳐지면(updatedAt 바뀜) 제외가 풀림
function exclOf(r) { const e = S.excl[r.id]; return e && e.recUpdatedAt === r.updatedAt ? e : null; }
function autoRecords() { return pendingRecords().filter((r) => !exclOf(r)); }
function autoDates() { return [...new Set(autoRecords().map((r) => r.date))]; }
async function pruneExcl() {
  const byId = new Map((S.data ? S.data.records : []).map((r) => [r.id, r]));
  let changed = false;
  for (const id of Object.keys(S.excl)) {
    const r = byId.get(id);
    if (!r || (r.neis && r.neis.done) || r.updatedAt !== S.excl[id].recUpdatedAt) { delete S.excl[id]; changed = true; }
  }
  if (changed) await store.saveExcluded(S.excl);
}
async function rememberExcluded(items) {
  const now = new Date().toISOString();
  for (const it of items) {
    if (it.status !== 'skipped' && it.status !== 'error') continue;
    for (const r of it.recs) S.excl[r.id] = { reason: it.reason || 'error', message: it.message || '', recUpdatedAt: r.updatedAt, at: now };
  }
  await store.saveExcluded(S.excl);
}
function recordLine(r) { return describeKind(r).trim(); }

// ---------- 토스트 ----------
let toastTimer = null;
function toast(msg, danger) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.toggle('toast-danger', !!danger);
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, danger ? 5000 : 2600);
}

// ---------- 나이스 탭과 통신 ----------
async function sendToTab(tabId, cmd, args) {
  let res;
  try {
    res = await chrome.tabs.sendMessage(tabId, { ah: 'neis-cmd', cmd, args: args || {} }, { frameId: 0 });
  } catch (e) {
    throw new PanelError('no_content', '나이스 페이지와 연결하지 못했습니다. 나이스 페이지를 새로고침(F5)한 뒤 다시 시도하세요.');
  }
  if (!res) throw new PanelError('no_content', '나이스 페이지에서 응답이 없습니다. 페이지를 새로고침(F5)한 뒤 다시 시도하세요.');
  if (!res.ok) throw new PanelError(res.error.code, res.error.message, res.error.data);
  return res.result;
}
function cmd(name, args) {
  const tabId = S.session ? S.session.tabId : S.conn.tabId;
  if (tabId == null) return Promise.reject(new PanelError('no_tab', `나이스 화면을 찾지 못했습니다. ${NEIS_GUIDE}`));
  return sendToTab(tabId, name, args);
}

async function detect() {
  let tabs = [];
  try { tabs = await chrome.tabs.query({ url: NEIS_URLS }); } catch (e) { tabs = []; }
  let cur = null;
  try { [cur] = await chrome.tabs.query({ active: true, lastFocusedWindow: true }); } catch (e) { /* 없음 */ }
  tabs.sort((a, b) => {
    const sa = (cur && a.id === cur.id ? 4 : 0) + (a.active ? 2 : 0);
    const sb = (cur && b.id === cur.id ? 4 : 0) + (b.active ? 2 : 0);
    return sb - sa || (b.lastAccessed || 0) - (a.lastAccessed || 0);
  });
  if (S.session) tabs.sort((a, b) => (b.id === S.session.tabId) - (a.id === S.session.tabId));
  let next = { state: tabs.length ? 'noscreen' : 'notab' };
  for (const t of tabs.slice(0, 5)) {
    try {
      const info = await sendToTab(t.id, 'detect');
      if (info.neis) { next = { state: 'ok', tabId: t.id, info }; break; }
    } catch (e) {
      if (next.state !== 'noscreen') next = { state: 'noscript' };
    }
  }
  const changed = JSON.stringify(next) !== JSON.stringify(S.conn);
  S.conn = next;
  if (changed) render();
}

chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.ah !== 'neis-event') return;
  const ev = msg.event || {};
  if (ev.type === 'log') {
    S.logs.push({ at: ev.at || Date.now(), level: ev.level, msg: ev.msg });
    if (S.logs.length > 200) S.logs.splice(0, S.logs.length - 200);
    renderLog();
  }
});

// ---------- 나이스 입력 (v0.4: 날짜별 일괄 자동 입력 -> 선생님 확인 -> 저장 -> 다음 날짜) ----------
const SKIP_LABEL = {
  existing: '나이스에 이미 값이 있음', twoRecords: '같은 날 기록 2건 이상', closed: '교시 마감 칸',
  name_mismatch: '이름 불일치', not_found: '나이스 표에 없는 번호', no_name: '명단에 없는 번호', period_range: '교시 수 초과',
  noRows: '나이스에 이 날짜 학생 목록이 없습니다(휴일일 수 있음)', keptDeleted: '나이스에서 지운 기록 (앱 기록은 남김, 자동 입력에서 뺌)',
  changedAfterSave: '나이스 저장 직후 다른 기기에서 기록이 바뀜. 나이스 값과 비교 필요',
};
const BLOCKING_CODES = ['date_changed', 'class_changed', 'no_grid_date', 'popup_open', 'cmn_open', 'no_screen', 'no_content', 'no_tab'];
function stale(run) { return !S.session || S.session.runId !== run; }
const blockReason = (r) => neisBlockReason(r);

// 기록을 바꾸는 작업(동기화·저장 반영·저장 직전 확인)은 한 번에 하나씩 (겹치면 앞 작업의 결과를 덮어쓸 수 있음)
let dataLock = Promise.resolve();
function withDataLock(fn) {
  const run = dataLock.then(() => fn());
  dataLock = run.catch(() => {});
  return run;
}
// 기록 바꾸기: 드라이브를 먼저 받아 mergeData 로 병합한 뒤 바꾸고 저장·업로드 (contract 5·6절)
function commitData(mutate) {
  return withDataLock(async () => {
    S.committing = true;
    try {
      while (S.checking) await sleep(50); // 자동 확인이 끝난 뒤 받기
      let token = null, fileId = null;
      if (S.drive.connected && drive.hasClientId()) {
        try {
          token = await drive.getToken(false);
          const d = await drive.download(token);
          fileId = d.fileId;
          if (d.data) S.data = mergeData(S.data, d.data);
        } catch (e) {
          token = null;
          toast('드라이브를 받지 못해 이 PC에 먼저 저장했습니다. 다음 동기화 때 올라갑니다.', true);
        }
      }
      const now = new Date().toISOString();
      mutate(S.data, now);
      S.data.updatedAt = now;
      await store.saveData(S.data);
      if (token) {
        try {
          const up = await drive.upload(token, fileId, S.data);
          S.remote.fileId = up.fileId; S.remote.stamp = up.stamp;
          S.drive = { connected: true, lastSyncAt: new Date().toISOString() };
          await store.saveDriveState(S.drive);
        } catch (e) { scheduleSync(); }
      } else {
        scheduleSync();
      }
    } finally {
      S.committing = false;
    }
  });
}
// 구분이 바뀔 때 서류 목록: 같은 종류(질병 서류는 처방전·진료확인서·학부모확인서 중 하나)는 제출 상태를 옮김
function rebuildDocs(old, div, tag) {
  const pool = [...(old || [])];
  return requiredDocs(div, tag).map((d) => {
    const same = (o) => o.type === d.type || (ILL_DOC_TYPES.includes(d.type) && ILL_DOC_TYPES.includes(o.type));
    const i = pool.findIndex(same);
    if (i < 0) return d;
    return { ...pool.splice(i, 1)[0] };
  });
}
const neisDone = (r, now) => { r.neis = { ...(r.neis || {}), done: true, doneAt: now, updatedAt: now }; };

function describeMarks(m, totMax) {
  const out = [];
  if (m.jo === '/') out.push('조회');
  const n = totMax || Object.keys(m.gyo || {}).length;
  for (let i = 1; i <= n; i++) if (m.gyo[i] === '/') out.push(`${i}교시`);
  if (m.jong === '/') out.push('종례');
  return out.length ? out.join(', ') : '표시 없음';
}
function describeRow(row) {
  if (!row || !row.gb) return '비어 있음';
  return [row.gb, describeMarks(row.marks, row.totMax), row.reason].filter(Boolean).join(' · ');
}
// 구분이 비어 있어도 실제 표시 내용을 그대로 (확장이 입력하지 않은 행 안내용)
function describeRowFull(row) {
  if (!row) return '';
  if (!row.gb && !rowHasValue(row)) return '비어 있음';
  return [row.gb || '구분 빈칸', describeMarks(row.marks, row.totMax), row.reason].filter(Boolean).join(' · ');
}
function rowMarked(row) {
  const n = row.totMax || Object.keys(row.marks.gyo).length;
  const out = [];
  for (let i = 1; i <= n; i++) if (row.marks.gyo[i] === '/') out.push(i);
  return out;
}
const rowHasValue = (row) => !!(row.gb || String(row.reason || '').trim() || row.marks.jo === '/' || row.marks.jong === '/' || rowMarked(row).length);
// 나이스 행 -> 앱 기록 필드 (역매핑). 앱 기록으로 옮길 수 없으면 errors 에 이유 (이때 div/kind 는 null 이며 절대 쓰지 않음)
function reverseMap(row) {
  const gb = String(row.gb || '').trim();
  const div = NEIS_DIVS.find((d) => gb.startsWith(DIVS[d].ko)) || null;
  const kind = Object.keys(KINDS).find((k) => gb.endsWith(KINDS[k].ko)) || null;
  const marked = rowMarked(row);
  const reason = String(row.reason || '').trim();
  const errors = [];
  if (!div || !kind || chulgyulGb(div, kind) !== gb) errors.push(`나이스 구분 '${gb || '빈칸'}'은(는) 확장프로그램이 아는 값이 아니라 앱 기록으로 옮길 수 없습니다.`);
  else if ((kind === 'late' || kind === 'early') && !marked.length) errors.push(`${KINDS[kind].ko}인데 교시 표시가 없어 몇 교시인지 알 수 없습니다.`);
  else if (kind === 'result' && !marked.length) errors.push('결과인데 교시 표시가 없습니다.');
  if (errors.length) return { div: null, kind: null, period: null, periods: [], reason, errors };
  return {
    div, kind,
    period: kind === 'early' ? marked[0] : kind === 'late' ? marked[marked.length - 1] : null,
    periods: kind === 'result' ? marked : [],
    reason, errors,
  };
}
function recordDiffs(rec, p) {
  if (p.errors && p.errors.length) return p.errors.slice();
  const d = [];
  if (rec.div !== p.div || rec.kind !== p.kind) d.push(`구분·종류: ${recordLine(rec)} → ${recordLine({ ...rec, ...p })}`);
  else if ((rec.kind === 'late' || rec.kind === 'early') && Number(rec.period) !== Number(p.period)) d.push(`교시: ${rec.period}교시 → ${p.period}교시`);
  else if (rec.kind === 'result' && (rec.periods || []).join(',') !== p.periods.join(',')) d.push(`교시: ${(rec.periods || []).join(', ')} → ${p.periods.join(', ') || '없음'}`);
  if (String(rec.reason || '').trim() !== p.reason) d.push(`사유: '${rec.reason || ''}' → '${p.reason}'`);
  return d;
}
// 나이스 표시(조회·교시·종례)를 기대값(expectedNeisMarks)과 비교. 교시 마감 칸은 빼고 비교
function markWarnings(row, p) {
  const exp = expectedNeisMarks(p, row.totMax || periodsPerDay());
  if (!exp) return ['기대값을 만들 수 없습니다.'];
  const m = row.marks;
  const closed = new Set(m.closed || []);
  const show = (v) => (v === '/' ? '표시' : '빈칸');
  const w = [];
  if ((m.jo === '/') !== (exp.jo === '/')) w.push(`조회: 나이스 ${show(m.jo)}, 기대 ${show(exp.jo)}`);
  const n = row.totMax || Object.keys(exp.gyo).length;
  for (let i = 1; i <= n; i++) {
    if (closed.has(i)) continue;
    if ((m.gyo[i] === '/') !== (exp.gyo[i] === '/')) w.push(`${i}교시: 나이스 ${show(m.gyo[i])}, 기대 ${show(exp.gyo[i])}`);
  }
  if ((m.jong === '/') !== (exp.jong === '/')) w.push(`종례: 나이스 ${show(m.jong)}, 기대 ${show(exp.jong)}`);
  return w;
}
function compareEntry(it, row) {
  const p = reverseMap(row);
  if (p.errors.length) return { type: 'invalid', it, row, errors: p.errors };
  const diffs = recordDiffs(it.rec, p);
  return { type: diffs.length ? 'update' : 'same', it, row, parsed: p, diffs, warns: markWarnings(row, p), ack: false };
}

async function startRun() {
  if (S.conn.state !== 'ok') { toast(NEIS_GUIDE, true); return; }
  if (!rosterList().length) { toast('먼저 [명단] 탭에서 나이스 명단을 불러오세요.', true); switchTab('roster'); return; }
  if (!autoDates().length) { toast('자동으로 입력할 기록이 없습니다.'); return; }
  S.notice = null;
  S.session = {
    runId: ++runCounter, tabId: S.conn.tabId, phase: 'moving', date: null, ctx: null,
    doneDates: new Set(), excludedIds: new Set(), finished: [], items: [], review: null, plan: null, prep: null, error: null,
    edits: {}, editor: null, warnDirect: null,
  };
  nextDate();
}

async function nextDate() {
  const s = S.session;
  const date = autoDates().find((d) => !s.doneDates.has(d));
  if (!date) { s.phase = 'allDone'; render(); return; }
  goDate(date);
}

async function goDate(date) {
  const s = S.session;
  const run = s.runId;
  Object.assign(s, { date, phase: 'moving', items: [], review: null, plan: null, prep: null, error: null, errorCode: null, errorData: null, autoIdx: 0,
    edits: {}, editor: null, warnDirect: null, remoteChanged: 0, baseline: null, reloadDialog: null,
    ctx: { date, ...classOfRoster() } });
  render();
  let res;
  try {
    res = await cmd('setDate', { date });
  } catch (e) {
    if (stale(run)) return;
    return fail(e, 'date');
  }
  if (stale(run)) return;
  detect();
  if (res && res.empty) { skipEmptyDate(date); return; }
  // 입력 전 표(행 상태가 모두 1일 때)를 기준값으로 기억: 저장 목록에서 '실제로 바뀐 행'을 가릴 때 씀
  try {
    const day = await cmd('readDay', { ctx: s.ctx });
    s.baseline = day.rows.every((r) => !r.dirty) ? new Map(day.rows.map((r) => [r.no, r.sig])) : null;
  } catch (e) {
    if (stale(run)) return;
    return fail(e, 'date');
  }
  if (stale(run)) return;
  const blocked = pendingRecords().filter((r) => r.date === date && !s.excludedIds.has(r.id) && blockReason(r));
  if (blocked.length) {
    s.prep = { ids: blocked.map((r) => r.id), draft: Object.fromEntries(blocked.map((r) => [r.id, { div: NEIS_DIVS.includes(r.div) ? r.div : '', reason: r.reason || '' }])) };
    s.phase = 'prepare'; render();
    return;
  }
  runAuto();
}

function fail(e, at) {
  const s = S.session;
  let msg = e.message;
  if (e.code === 'name_mismatch' && e.data) msg += ` (명단: ${e.data.expected}, 나이스: ${e.data.actual})`;
  Object.assign(s, { phase: 'error', error: msg, errorCode: e.code, errorAt: at, errorData: e.data || null });
  render();
}
// 나이스에 그 날짜 학생 목록이 없음(휴일 등): 자동 진행에서 건너뛰고 '직접 확인이 필요한 기록'으로
async function skipEmptyDate(date) {
  const s = S.session;
  const run = s.runId;
  const at = new Date().toISOString();
  for (const r of pendingRecords().filter((x) => x.date === date && !exclOf(x))) {
    S.excl[r.id] = { reason: 'noRows', message: '', recUpdatedAt: r.updatedAt, at };
  }
  await store.saveExcluded(S.excl);
  if (stale(run)) return;
  s.doneDates.add(date);
  toast(`${formatDateKo(date)}: 나이스에 학생 목록이 없어 건너뜁니다 (휴일일 수 있음).`, true);
  nextDate();
}

// 미정 구분·기타 빈 사유: 그 날짜 시작 전에 정함 -> 앱 기록 갱신 (본문 변경이므로 record.updatedAt 갱신)
async function finishPrepare() {
  const s = S.session;
  const recs = s.prep.ids.map((id) => S.data.records.find((r) => r.id === id)).filter(Boolean);
  for (const r of recs) {
    const d = s.prep.draft[r.id];
    const why = blockReason({ ...r, div: d.div, reason: d.reason });
    if (why) { toast(`${r.no}번: ${why}`, true); return; }
  }
  const run = s.runId;
  await commitData((data, now) => {
    for (const r of data.records) {
      const d = s.prep.draft[r.id];
      if (!d) continue;
      const divChanged = r.div !== d.div;
      r.div = d.div;
      r.reason = String(d.reason || '').trim();
      if (divChanged) r.docs = rebuildDocs(r.docs, r.div, r.tag);
      r.updatedAt = now;
    }
  });
  if (stale(run)) return;
  toast(`기록 ${recs.length}건의 구분·사유를 저장했습니다.`);
  s.prep = null;
  runAuto();
}
function skipPrepare() {
  const s = S.session;
  s.prep.ids.forEach((id) => s.excludedIds.add(id));
  s.prep = null;
  runAuto();
}

function buildItems(date) {
  const s = S.session;
  const recs = pendingRecords().filter((r) => r.date === date && !s.excludedIds.has(r.id) && !blockReason(r));
  const byNo = new Map();
  for (const r of recs) { if (!byNo.has(r.no)) byNo.set(r.no, []); byNo.get(r.no).push(r); }
  return [...byNo.values()].map((g) => ({
    no: g[0].no, ids: g.map((r) => r.id), recs: g, rec: g[0], name: nameOf(g[0].no), manual: g.length > 1,
    status: g.length > 1 ? 'skipped' : 'wait', reason: g.length > 1 ? 'twoRecords' : '', message: '', warnings: [],
  }));
}

async function runAuto() {
  const s = S.session;
  const run = s.runId;
  if (!s.items.length) s.items = buildItems(s.date);
  s.phase = 'auto'; s.error = null; render();
  const periodsPerDay = (S.data && S.data.settings.periodsPerDay) || 7;
  for (; s.autoIdx < s.items.length; s.autoIdx++) {
    const it = s.items[s.autoIdx];
    if (it.status !== 'wait') continue;
    const r = it.rec;
    it.status = 'current'; render();
    try {
      const res = await cmd('autoStudent', {
        ctx: s.ctx, no: r.no, name: it.name, kind: r.kind, period: r.period, periods: r.periods,
        divNeis: DIVS[r.div].neis, sortNeis: KINDS[r.kind].neis, divKo: DIVS[r.div].ko, kindKo: KINDS[r.kind].ko,
        reason: r.reason || '', expectedGb: chulgyulGb(r.div, r.kind), expected: expectedNeisMarks(r, periodsPerDay),
      });
      if (stale(run)) return;
      Object.assign(it, { status: res.status, reason: res.reason || '', message: res.message || '', warnings: res.warnings || [] });
    } catch (e) {
      if (stale(run) || e.code === 'aborted') return;
      it.status = 'wait';
      return fail(e, 'auto');
    }
  }
  await rememberExcluded(s.items);
  if (stale(run)) return;
  enterReview();
}

async function enterReview() {
  const s = S.session;
  const run = s.runId;
  try {
    const day = await cmd('readDay', { ctx: s.ctx });
    if (stale(run)) return;
    s.review = day.rows;
    await paint();
  } catch (e) {
    if (stale(run)) return;
    return fail(e, 'review');
  }
  s.phase = 'review'; s.plan = null; s.error = null;
  render();
}
async function paint() {
  const s = S.session;
  const entered = s.items.filter((it) => it.status === 'done').map((it) => it.no);
  const review = s.items.filter((it) => it.status !== 'done').map((it) => it.no);
  await cmd('highlightRows', { entered, review }).catch(() => {});
}

// [확인 완료 · 저장] -> 나이스 최종값과 앱 기록 비교 -> 저장 목록
// 저장 허용 행 = (a) 이번 날짜에 확장이 입력한 기록의 행 + (b) 앱에 없는 행 중 선생님이 '앱에 추가'를 고른 행
//   (+ (c) 패널에서 편집한 행: [수정 반영]으로 다시 입력되므로 (a)에 들어감)
// 그 밖에 입력 전 표와 값이 달라진 행이 하나라도 있으면 저장하지 않는다.
async function buildPlan() {
  const s = S.session;
  const run = s.runId;
  let rows;
  try { rows = (await cmd('readDay', { ctx: s.ctx })).rows; } catch (e) { if (!stale(run)) fail(e, 'review'); return; }
  if (stale(run)) return;
  s.review = rows;
  const base = s.baseline;
  const changed = (row) => row.dirty && !(base && base.get(row.no) === row.sig);
  const byNo = new Map(s.items.map((it) => [it.no, it]));
  const entries = [], blocked = [], reverted = [], unchanged = [];
  const block = (row, it, why, entered) => blocked.push({ row, it: it || null, why, entered: !!entered });
  for (const row of rows) {
    const it = byNo.get(row.no);
    const auto = it && !it.manual;
    if (auto && it.status === 'done') {
      if (!row.dirty) {
        // 행 상태가 '변경 없음'인데 비어 있음 = 나이스 [조회] 등으로 표가 되돌려짐 (지워진 것이 아님)
        if (!rowHasValue(row)) { reverted.push(row.no); continue; }
        const e = compareEntry(it, row);
        if (e.type === 'same' && !e.warns.length) entries.push(e);
        continue;
      }
      if (!row.gb) {
        if (rowHasValue(row)) block(row, it, '구분 칸이 비었는데 교시 표시나 사유가 남아 있습니다. 나이스에서 이 학생을 다시 입력하거나 표시를 모두 지우세요.', true);
        else entries.push({ type: 'deleted', it, row, choice: '' });
        continue;
      }
      const e = compareEntry(it, row);
      if (e.type === 'invalid') block(row, it, e.errors.join(' '), true);
      else entries.push(e);
      continue;
    }
    if (auto && it.status === 'error' && changed(row)) {
      const e = row.gb ? compareEntry(it, row) : null;
      if (e && e.type === 'same') entries.push(e);
      else block(row, it, e && e.type === 'invalid' ? e.errors.join(' ')
        : `확장프로그램이 입력하다 멈춘 학생인데 나이스 값이 앱 기록과 다릅니다${e ? ` (${e.diffs.join(' / ')})` : ''}. 패널의 [수정]으로 고치거나 나이스에서 되돌리세요.`, true);
      continue;
    }
    if (auto && it.reason === 'existing' && !row.dirty && row.gb) {
      // 나이스에 이미 있던 값이 기록과 완전히 같으면 저장 없이 입력 완료
      const e = compareEntry(it, row);
      if (e.type === 'same' && !e.warns.length) entries.push(e);
      continue;
    }
    if (!changed(row)) { if (row.dirty) unchanged.push({ no: row.no, sig: row.sig }); continue; }
    if (it) {
      block(row, it, it.manual ? '같은 날 기록이 2건 이상인 학생은 확장프로그램이 저장하지 않습니다.'
        : `자동 입력에서 뺀 학생입니다 (${SKIP_LABEL[it.reason] || it.message || '입력 안 함'}).`);
      continue;
    }
    if (!row.gb) { block(row, null, ''); continue; }
    const p = reverseMap(row);
    if (p.errors.length) { block(row, null, p.errors.join(' ')); continue; }
    entries.push({ type: 'added', row, parsed: p, diffs: [], warns: markWarnings(row, p), ack: false, choice: '' });
  }
  s.plan = { entries, blocked, reverted, unchanged, rows };
  s.phase = 'plan';
  render();
}
// 저장할 수 없는 이유 (없으면 '')
function planIssue(P) {
  if (!P) return '저장 목록이 없습니다.';
  if (P.reverted.length) return '나이스 표가 되돌려졌습니다. [다시 입력]을 누르세요.';
  if (P.blocked.length) return '확장프로그램이 입력하지 않은 칸이 바뀌어 있습니다.';
  if (P.entries.some((e) => (e.type === 'deleted' || e.type === 'added') && !e.choice)) return '선택하지 않은 항목이 있습니다.';
  if (P.entries.some((e) => e.type === 'added' && e.choice === 'ignore')) return '[무시]를 고른 행이 나이스에 남아 있습니다. 나이스에서 되돌린 뒤 다시 확인하세요.';
  if (P.entries.some((e) => e.warns && e.warns.length && !e.ack && !(e.type === 'added' && e.choice === 'ignore'))) return '기대값과 다른 행을 나이스에서 보고 [확인함]을 체크하세요.';
  return '';
}
// 같은 날짜 기록 중 나이스와 관계있는 변경(서류 제출만 바뀐 것 제외)
function sessionDateChanges(diff, before, merged, date) {
  return diff.ids.filter((id) => diff.kinds[id] !== 'docs'
    && [before, merged].some((d) => d && d.records.some((r) => r.id === id && r.date === date)));
}
// [이대로 저장] 직후, 나이스 [저장]을 누르기 전에 드라이브를 한 번 더 받아 이 날짜 기록이 바뀌었는지 확인 (드라이브 미연결이면 건너뜀)
function preSaveRemoteCheck() {
  if (!(S.drive.connected && drive.hasClientId())) return Promise.resolve({ ok: true, skipped: true });
  return withDataLock(async () => {
    S.committing = true;
    try {
      while (S.checking) await sleep(50);
      let d;
      try {
        const token = await drive.getToken(false);
        d = await drive.download(token);
      } catch (e) {
        return { ok: false, message: '구글 드라이브에서 최신 기록을 확인하지 못해 저장하지 않았습니다. 인터넷 연결을 확인한 뒤 다시 누르세요. (구글 연결을 해제하면 이 PC 기록만으로 저장합니다.)' };
      }
      if (d.fileId) { S.remote.fileId = d.fileId; S.remote.stamp = d.stamp; }
      if (!d.data) return { ok: true };
      const before = S.data;
      const merged = mergeData(S.data, d.data);
      const diff = diffRemoteChanges(before, merged);
      S.data = merged;
      await store.saveData(merged);
      if (!diff.changed) return { ok: true };
      await pruneExcl();
      const s = S.session;
      const onDate = s ? sessionDateChanges(diff, before, merged, s.date) : [];
      if (onDate.length) { s.remoteChanged = (s.remoteChanged || 0) + onDate.length; return { ok: false, message: '' }; }
      toast(`휴대폰에서 바뀐 기록 ${diff.changed}건을 반영했습니다.`);
      return { ok: true };
    } finally {
      S.committing = false;
    }
  });
}

async function doSave() {
  const s = S.session;
  const why = planIssue(s.plan);
  if (why || s.remoteChanged) { toast(why || '다른 기기에서 바뀐 기록이 있어 저장하지 않습니다.', true); return; }
  const run = s.runId;
  const plan = s.plan;
  const date = s.date;
  // 허용 목록은 저장 목록을 만들 때 읽은 행과 값으로 고정 (나이스가 저장 직전에 '바뀐 행 ⊆ 허용 목록', '값 = 목록 값'을 확인)
  const saveRows = plan.entries.filter((e) => e.row.dirty && (e.type !== 'added' || e.choice === 'add'))
    .map((e) => ({ no: e.row.no, sig: e.row.sig })).concat(plan.unchanged);
  s.phase = 'saveCheck'; render();
  const rc = await preSaveRemoteCheck();
  if (stale(run)) return;
  if (!rc.ok) { s.phase = 'plan'; render(); if (rc.message) toast(rc.message, true); return; }
  s.phase = 'saving'; render();
  let res;
  try {
    res = await cmd('save', { ctx: s.ctx, rows: saveRows });
  } catch (e) {
    if (stale(run)) return;
    return fail(e, 'save');
  }
  if (stale(run)) return;
  let count = 0;
  const conflicts = [], kept = [];
  await commitData((data, now) => {
    const find = (id) => data.records.find((r) => r.id === id);
    // 저장 목록을 만든 뒤 다른 기기에서 본문이 바뀐 기록은 완료 표시하지 않음 (나이스 값과 다를 수 있음)
    const fresh = (e) => {
      const r = find(e.it.rec.id);
      if (!r) return null;
      if (r.updatedAt !== e.it.rec.updatedAt) { conflicts.push(r); return null; }
      return r;
    };
    for (const e of plan.entries) {
      if (e.type === 'same') { const r = fresh(e); if (r) { neisDone(r, now); count++; } }
      else if (e.type === 'update') {
        const r = fresh(e);
        if (!r) continue;
        const divChanged = r.div !== e.parsed.div;
        Object.assign(r, { div: e.parsed.div, kind: e.parsed.kind, period: e.parsed.period, periods: e.parsed.periods, reason: e.parsed.reason });
        if (divChanged) r.docs = rebuildDocs(r.docs, r.div, r.tag);
        r.updatedAt = now;
        neisDone(r, now); count++;
      } else if (e.type === 'deleted' && e.choice === 'delete') {
        data.records = data.records.filter((r) => r.id !== e.it.rec.id);
        data.deleted = (data.deleted || []).filter((d) => d.id !== e.it.rec.id).concat([{ id: e.it.rec.id, deletedAt: now }]);
      } else if (e.type === 'deleted' && e.choice === 'keep') {
        const r = find(e.it.rec.id);
        if (r) kept.push(r);
      } else if (e.type === 'added' && e.choice === 'add') {
        const r = createRecord({ date, no: e.row.no, div: e.parsed.div, kind: e.parsed.kind, period: e.parsed.period, periods: e.parsed.periods,
          reason: e.parsed.reason, docs: requiredDocs(e.parsed.div, null) });
        neisDone(r, now);
        data.records.push(r); count++;
      }
    }
  });
  await cmd('clearHighlights').catch(() => {});
  const at = new Date().toISOString();
  for (const r of kept) S.excl[r.id] = { reason: 'keptDeleted', message: '', recUpdatedAt: r.updatedAt, at };
  for (const r of conflicts) S.excl[r.id] = { reason: 'changedAfterSave', message: '', recUpdatedAt: r.updatedAt, at };
  if (kept.length || conflicts.length) await store.saveExcluded(S.excl);
  if (stale(run)) return;
  s.finished.push({ date, count, saved: !!res.saved, left: s.items.filter((it) => !plan.entries.some((e) => e.it === it)).length });
  await pruneExcl();
  s.doneDates.add(date);
  if (conflicts.length) toast(`저장하는 사이 다른 기기에서 바뀐 기록 ${conflicts.length}건은 입력 완료로 표시하지 않았습니다. '직접 확인이 필요한 기록'에서 확인하세요.`, true);
  else toast(res.saved ? `${formatDateKo(date)} 저장 완료 · ${count}건 입력 완료` : `${formatDateKo(date)}: 나이스에서 바뀐 내용이 없어 저장 없이 넘어갑니다.`);
  nextDate();
}
// 저장 목록에서 '나이스 표가 되돌려졌습니다' -> [다시 입력]
function redoDate() {
  const s = S.session;
  const clean = (s.plan && s.plan.rows || []).every((r) => !r.dirty);
  s.plan = null; s.items = []; s.autoIdx = 0;
  if (clean) goDate(s.date);
  else reloadAndRedo(s.runId);
}

// ---------- 확인 단계: 사이드 패널에서 수정 (편집은 쌓아 두고 [수정 반영 후 다시 입력] 한 번) ----------
const periodsPerDay = () => (S.data && S.data.settings.periodsPerDay) || 7;
function editCount(s) { return Object.keys(s.edits || {}).length; }
function openEditor(s, mode, item) {
  if (mode === 'add') {
    s.editor = { mode, key: null, recId: null, no: '', draft: { div: 'ill', kind: 'absent', period: null, periods: [], reason: '', tag: null }, err: '' };
  } else {
    const key = item.addKey || item.ids[0];
    const prev = s.edits[key];
    const base = prev && prev.fields ? prev.fields : item.rec;
    s.editor = { mode: item.addKey ? 'add' : 'edit', key, recId: item.addKey ? null : item.ids[0], no: item.no,
      draft: { div: NEIS_DIVS.includes(base.div) ? base.div : 'ill', kind: base.kind, period: base.period || null,
        periods: [...(base.periods || [])], reason: base.reason || '', tag: base.tag || null, reasonChip: base.tag ? base.reason : null }, err: '' };
  }
  render();
}
function editorError(ed) {
  const d = ed.draft;
  if (ed.mode === 'add' && !Number(ed.no)) return '번호를 고르세요.';
  if (!NEIS_DIVS.includes(d.div)) return '구분을 고르세요.';
  if (!KINDS[d.kind]) return '종류를 고르세요.';
  if ((d.kind === 'late' || d.kind === 'early') && !d.period) return '교시를 고르세요.';
  if (d.kind === 'result' && !d.periods.length) return '빠진 교시를 하나 이상 고르세요.';
  if (d.div === 'etc' && !String(d.reason).trim()) return '기타는 사유가 필요합니다.';
  return '';
}
function editorApply(s) {
  const ed = s.editor;
  const err = editorError(ed);
  if (err) { ed.err = err; render(); return; }
  const d = ed.draft;
  const fields = { div: d.div, kind: d.kind, period: (d.kind === 'late' || d.kind === 'early') ? Number(d.period) : null,
    periods: d.kind === 'result' ? [...d.periods].sort((a, b) => a - b) : [], reason: String(d.reason).trim(), tag: d.tag || null };
  if (ed.mode === 'add') {
    const key = ed.key || `add:${Number(ed.no)}`;
    s.edits[key] = { type: 'add', no: Number(ed.no), fields };
  } else {
    s.edits[ed.key] = { type: 'update', recId: ed.recId, no: ed.no, fields };
  }
  s.editor = null; render();
}
function editorDelete(s) {
  const ed = s.editor;
  if (ed.mode === 'add') delete s.edits[ed.key];
  else s.edits[ed.key] = { type: 'delete', recId: ed.recId, no: ed.no };
  s.editor = null; render();
}
// 나이스에서 직접 고친 행 (확장이 입력하지 않은 값): 수정 반영의 [조회]로 지워짐
function directChanges(s) {
  const byNo = new Map(s.items.map((it) => [it.no, it]));
  const out = [];
  for (const row of s.review || []) {
    if (!row.dirty) continue;
    const it = byNo.get(row.no);
    if (!it || it.status !== 'done' || !row.gb || recordDiffs(it.rec, reverseMap(row)).length) out.push(row.no);
  }
  return out;
}
// 다른 기기에서 이 날짜 기록이 바뀐 경우(remoteChanged)는 고친 내용이 없어도 같은 경로로 다시 불러와 다시 입력
async function applyEdits(force) {
  const s = S.session;
  const run = s.runId;
  if (!editCount(s) && !s.remoteChanged) return;
  try { s.review = (await cmd('readDay', { ctx: s.ctx })).rows; } catch (e) { if (!stale(run)) fail(e, 'review'); return; }
  if (stale(run)) return;
  const direct = directChanges(s);
  if (direct.length && !force) { s.warnDirect = direct; render(); return; }
  s.warnDirect = null;
  s.phase = 'reapply'; render();
  const edits = Object.values(s.edits);
  await commitData((data, now) => {
    for (const e of edits) {
      if (e.type === 'update') {
        const r = data.records.find((x) => x.id === e.recId);
        if (!r) continue;
        const divChanged = r.div !== e.fields.div || (e.fields.tag || null) !== (r.tag || null);
        Object.assign(r, { div: e.fields.div, kind: e.fields.kind, period: e.fields.period, periods: e.fields.periods, reason: e.fields.reason, tag: e.fields.tag });
        if (divChanged) r.docs = rebuildDocs(r.docs, r.div, r.tag);
        r.updatedAt = now;
      } else if (e.type === 'delete') {
        data.records = data.records.filter((x) => x.id !== e.recId);
        data.deleted = (data.deleted || []).filter((x) => x.id !== e.recId).concat([{ id: e.recId, deletedAt: now }]);
      } else if (e.type === 'add') {
        data.records.push(createRecord({ date: s.date, no: e.no, ...e.fields, docs: requiredDocs(e.fields.div, e.fields.tag) }));
      }
    }
  });
  if (stale(run)) return;
  s.edits = {};
  await reloadAndRedo(run);
}
async function reloadAndRedo(run) {
  const s = S.session;
  s.phase = 'reapply'; s.reloadDialog = null; render();
  await cmd('clearHighlights').catch(() => {});
  try {
    let res = await cmd('reloadDay', { ctx: s.ctx });
    if (stale(run)) return;
    if (res && res.dialog != null) {
      // 나이스 확인창: 확장은 어떤 버튼도 누르지 않음. 선생님이 고른 뒤 표가 다시 불러와졌는지 확인하고서만 계속
      s.reloadDialog = res.dialog; s.phase = 'reloadAsk'; render();
      res = await cmd('waitReload', { ctx: s.ctx, before: res.before });
      if (stale(run)) return;
    }
  } catch (e) {
    if (stale(run) || e.code === 'aborted') return;
    s.reloadDialog = null;
    return fail(e, e.code === 'saved_maybe' ? 'savedMaybe' : 'reapply');
  }
  s.reloadDialog = null;
  toast('나이스 표를 다시 불러왔습니다. 다시 입력합니다.');
  s.items = []; s.autoIdx = 0;
  goDate(s.date);
}

function renderEditor(s) {
  const ed = s.editor;
  const d = ed.draft;
  const per = periodsPerDay();
  const seg = (act, items, cur) => `<div class="seg" role="radiogroup">${items.map(([v, t]) =>
    `<button class="seg-item" role="radio" aria-checked="${String(cur) === String(v)}" data-act="${act}" data-v="${v}">${esc(t)}</button>`).join('')}</div>`;
  let noField = '';
  if (ed.mode === 'add' && !ed.key) {
    const used = new Set(s.items.map((it) => it.no));
    Object.values(s.edits).forEach((e) => used.add(e.no));
    const opts = rosterList().filter((st) => !used.has(st.no));
    noField = `<div class="field"><label class="label" for="edNo">학생</label><select class="select" id="edNo" data-ed="no">
      <option value="">번호 선택</option>${opts.map((st) => `<option value="${st.no}"${Number(ed.no) === st.no ? ' selected' : ''}>${st.no}번 ${esc(st.name)}</option>`).join('')}</select></div>`;
  }
  let periodField = '';
  if (d.kind !== 'absent') {
    const hint = d.kind === 'late' ? (d.period ? `${d.period}교시까지 없음 (조회~${d.period}교시)` : '몇 교시까지 없었는지 고르세요')
      : d.kind === 'early' ? (d.period ? `${d.period}교시부터 없음 (${d.period}교시~종례)` : '몇 교시부터 없었는지 고르세요')
        : '빠진 교시를 모두 고르세요';
    const on = (n) => (d.kind === 'result' ? d.periods.includes(n) : Number(d.period) === n);
    periodField = `<div class="field"><div class="label-row"><span class="label">교시</span><span class="tiny muted">${esc(hint)}</span></div>
      <div class="chips chips-period">${Array.from({ length: per }, (_, i) => i + 1).map((n) =>
        `<button class="chip chip-num" aria-pressed="${on(n)}" data-act="edPeriod" data-v="${n}">${n}</button>`).join('')}</div></div>`;
  }
  const chips = ((S.data && S.data.settings.quickReasons) || []).map((q) =>
    `<button class="chip" aria-pressed="${d.reason === q.label}" data-act="edChip" data-v="${esc(q.label)}">${esc(q.label)}</button>`).join('');
  const title = ed.mode === 'add' ? (ed.no ? `${ed.no}번 추가` : '학생 추가') : `${ed.no}번 ${esc(nameOf(ed.no))} 수정`;
  return `<section class="card stack editor" data-testid="editor"><h2 class="card-title">${title}</h2>${noField}
    <div class="field"><span class="label">구분</span>${seg('edDiv', orderedNeisDivs(S.data && S.data.settings).map((v) => [v, DIVS[v].ko]), d.div)}</div>
    <div class="field"><span class="label">종류</span>${seg('edKind', Object.keys(KINDS).map((v) => [v, KINDS[v].ko]), d.kind)}</div>
    ${periodField}
    <div class="field"><label class="label" for="edReason">사유</label>${chips ? `<div class="chips" style="margin-bottom:var(--sp-2)">${chips}</div>` : ''}
      <input class="input" id="edReason" data-ed="reason" value="${esc(d.reason)}" placeholder="사유${d.div === 'etc' ? ' (기타는 필수)' : ''}"></div>
    ${ed.err ? `<div class="small danger-text" role="alert">${esc(ed.err)}</div>` : ''}
    <div class="btn-row"><button class="btn btn-secondary btn-sm" data-act="edCancel">취소</button>
      ${ed.mode === 'edit' || ed.key ? `<button class="btn btn-danger-outline btn-sm" data-act="edDelete">${ed.mode === 'add' ? '추가 취소' : '삭제 (이날 출석으로)'}</button>` : ''}
      <button class="btn btn-primary btn-sm" data-act="edApply">적용</button></div></section>`;
}
function editLabel(e) {
  if (e.type === 'delete') return '삭제 예정 (이날 출석으로)';
  const f = e.fields;
  return `${e.type === 'add' ? '추가 예정' : '수정 예정'}: ${recordLine(f)}${f.reason ? ` · ${f.reason}` : ''}`;
}

async function gotoSessionDate() {
  const s = S.session;
  if (!s || !s.date) return;
  const at = s.errorAt;
  let res;
  try { res = await cmd('setDate', { date: s.date }); } catch (e) { toast(e.message, true); return; }
  await detect();
  toast(res.restored ? `일자 칸을 ${formatDateKo(s.date)}로 되돌렸습니다.` : `${formatDateKo(s.date)}로 이동했습니다.`);
  // 다시 조회해야 했다면 입력한 내용이 사라졌으므로 그 날짜를 처음부터 다시 입력
  if (at === 'reapply') { reloadAndRedo(s.runId); return; }
  if (res.changed && at !== 'date') { s.items = []; s.autoIdx = 0; goDate(s.date); return; }
  if (at === 'date') goDate(s.date);
  else if (at === 'auto') runAuto();
  else enterReview();
}
function resumeAfterError() {
  const s = S.session;
  if (s.errorAt === 'savedMaybe') return;
  if (s.errorAt === 'reapply') reloadAndRedo(s.runId);
  else if (s.errorAt === 'date') goDate(s.date);
  else if (s.errorAt === 'auto') runAuto();
  else enterReview();
}

async function stopSession() {
  if (!S.session) return;
  const s = S.session;
  s.runId = ++runCounter;
  try { await cmd('abort'); } catch (e) { /* 무시 */ }
  await cmd('clearHighlights').catch(() => {});
  const unsaved = s.date && !s.doneDates.has(s.date) && !['allDone'].includes(s.phase);
  // 나이스 [저장] 확인 뒤에 멈춘 경우(알림 문구가 달랐음 등)는 저장됐을 수 있음
  const maybeSaved = s.phase === 'error' && s.errorData && s.errorData.afterConfirm;
  S.notice = !unsaved ? null : maybeSaved
    ? `멈췄습니다. ${formatDateKo(s.date)}은(는) 나이스에 저장됐을 수 있습니다. 나이스 알림을 닫은 뒤 [조회]를 눌러 표 값을 직접 확인하세요. 앱 기록은 입력 완료로 표시하지 않았습니다. 다시 [나이스 입력 시작]을 누르면 나이스 값이 기록과 같은 학생은 입력 완료로 표시됩니다.`
    : `멈췄습니다. ${formatDateKo(s.date)}은(는) 저장하지 않았습니다. 나이스 [조회]를 누르면 되돌아갑니다.`;
  S.session = null;
  render();
}

// ---------- 명단 ----------
async function confirmRoster() {
  const g = Number($('rcGrade').value), c = Number($('rcClass').value);
  if (!(g >= 1 && g <= 6) || !(c >= 1 && c <= 30)) { toast('학년과 반을 숫자로 입력하세요.', true); return; }
  S.roster = { ...S.rosterConfirm, grade: g, classNo: c };
  S.rosterConfirm = null;
  await store.saveRoster(S.roster);
  const up = await pushRosterToDrive(S.roster.students);
  toast(`${g}학년 ${c}반 명단 ${S.roster.students.length}명을 저장했습니다.${up ? ' 구글 드라이브에도 올렸습니다.' : ''}`);
  render();
}

// 명단(번호·이름만)을 드라이브 파일의 roster 필드에 올림. 기록과 같은 안전한 순서: 먼저 받기 -> mergeData -> 저장 -> 업로드 (commitData).
// 드라이브에 연결되어 있지 않으면 아무것도 하지 않음(이 PC에만 있음). 올렸으면 true
async function pushRosterToDrive(students, source = 'neis') {
  if (!S.drive.connected || !drive.hasClientId() || !S.data) return false;
  const list = students.map((st) => ({ no: st.no, name: st.name }));
  await commitData((data, now) => { data.roster = makeRoster(list, source, now); });
  return true;
}
// 드라이브의 명단을 비움 (students: [] + 새 updatedAt 이 다른 기기에서도 비움으로 전해짐)
async function clearDriveRoster() {
  if (!S.data) return false;
  await commitData((data, now) => { data.roster = makeRoster([], 'manual', now); });
  return true;
}
const rosterLater = () => { try { return localStorage.getItem(ROSTER_LATER_KEY) === '1'; } catch (e) { return false; } };
// 이 PC에 나이스 명단이 있고 드라이브에 roster 가 아직 없으면 올리기 안내 (한 번만, [나중에]는 기억)
const showUploadPrompt = () => S.drive.connected && drive.hasClientId() && !!S.data && localRosterOn() && !S.data.roster && !rosterLater();

async function importRoster() {
  if (S.conn.state !== 'ok') { toast(NEIS_GUIDE, true); return; }
  S.rosterBusy = true; render();
  try {
    const r = await cmd('readRoster');
    const year = (S.data && S.data.settings.schoolYear) || (r.date ? Number(r.date.slice(0, 4)) : new Date().getFullYear());
    const roster = { schoolYear: year, grade: r.grade, classNo: r.classNo, students: r.students, importedAt: new Date().toISOString(), classSource: 'neis' };
    if (r.grade == null || r.classNo == null) {
      // 나이스 화면에서 학년·반을 읽지 못함 -> 선생님이 확인
      S.rosterConfirm = { ...roster, classSource: 'teacher',
        grade: (S.data && S.data.settings.grade) || '', classNo: (S.data && S.data.settings.classNo) || '' };
      return;
    }
    S.roster = roster;
    await store.saveRoster(S.roster);
    const up = await pushRosterToDrive(roster.students);
    toast(`${r.students.length}명의 명단을 불러왔습니다.${up ? ' 구글 드라이브에도 올렸습니다.' : ''}`);
  } catch (e) {
    toast(e.message, true);
  } finally {
    S.rosterBusy = false; render();
  }
}

// ---------- 동기화 ----------
let syncTimer = null;
function scheduleSync(ms) {
  if (!S.drive.connected || !drive.hasClientId()) return;
  clearTimeout(syncTimer);
  syncTimer = setTimeout(() => syncNow(false, true), ms == null ? 2000 : ms);
}
async function syncNow(interactive, quiet) {
  if (!drive.hasClientId()) { if (!quiet) { toast('구글 연결이 설정되지 않았습니다. [설정] 탭을 확인하세요.', true); switchTab('settings'); } return; }
  if (!S.drive.connected && !interactive) { if (!quiet) { toast('먼저 [설정] 탭에서 구글 드라이브를 연결하세요.'); switchTab('settings'); } return; }
  if (S.syncing) return;
  S.syncing = true; render();
  try {
    // 저장 반영(commitData)과 겹치지 않게 같은 잠금 (겹치면 입력 완료 표시가 덮어써질 수 있음)
    await withDataLock(async () => {
      while (S.checking) await sleep(50);
      const token = await drive.getToken(interactive);
      const { fileId, data: remote, stamp } = await drive.download(token);
      S.remote.fileId = fileId; S.remote.stamp = stamp;
      if (!S.data && !remote) {
        S.drive = { connected: true, lastSyncAt: new Date().toISOString() };
      } else {
        const merged = mergeData(S.data, remote);
        S.data = merged;
        await store.saveData(merged);
        const up = await drive.upload(token, fileId, merged);
        S.remote.fileId = up.fileId; S.remote.stamp = up.stamp;
        S.drive = { connected: true, lastSyncAt: new Date().toISOString() };
      }
      await store.saveDriveState(S.drive);
    });
    if (!quiet) toast('동기화했습니다.');
  } catch (e) {
    if (!quiet || e.code === 'auth') toast(e.message, true);
  } finally {
    S.syncing = false; render();
    if (!pollTimer) schedulePoll(); // 연결·첫 동기화 뒤 자동 확인 시작
  }
}

// ---------- 자동 확인 (계약 5절) ----------
// 패널이 보이는 동안 일정 간격으로 드라이브 파일의 version|modifiedTime만 확인하고, 바뀌었을 때만 내려받아 병합한다.
// 저장된 토큰이 없으면 조용히 건너뛴다 (로그인 창·조용한 재요청 없음). 일괄 입력·수정 반영·저장 중에는 확인하지 않는다.
const POLL_DEFAULT_MS = 20000;
const BUSY_PHASES = ['moving', 'auto', 'saving', 'saveCheck', 'reapply', 'reloadAsk'];
function pollMs() {
  let v = Number(window.__AH_POLL_MS);
  if (!v) { try { v = Number(localStorage.getItem('ah.pollMs')); } catch (e) { v = 0; } }
  return v >= 200 ? v : POLL_DEFAULT_MS;
}
const autoCheckOn = () => S.drive.connected && drive.hasClientId() && !!S.data;
const sessionBusy = () => !!(S.session && BUSY_PHASES.includes(S.session.phase));
const pollBlocked = () => S.syncing || S.committing || S.checking || sessionBusy();
async function checkRemote() {
  if (!autoCheckOn() || document.hidden || !navigator.onLine || !S.remote.fileId || pollBlocked()) return;
  const token = await drive.peekToken();
  if (!token || pollBlocked()) return;
  S.checking = true;
  let reloadPrep = null;
  try {
    const meta = await drive.getMeta(token, S.remote.fileId);
    S.remote.lastCheckAt = new Date().toISOString();
    const stamp = drive.metaStamp(meta);
    if (stamp && stamp === S.remote.stamp) return;
    const remote = await drive.downloadById(token, S.remote.fileId);
    if (S.syncing || S.committing || sessionBusy()) return; // 그 사이 작업이 시작됨: 다음 확인에서 다시
    const before = S.data;
    const merged = mergeData(S.data, remote);
    const diff = diffRemoteChanges(before, merged);
    S.data = merged;
    await store.saveData(merged);
    S.remote.stamp = stamp;
    if (!diff.changed) { if (diff.roster) render(); return; } // 앱에서 바뀐 명단: 폴백용 S.data.roster 만 갱신 (이 PC의 나이스 명단은 그대로)
    await pruneExcl();
    const s = S.session;
    let shown = diff.changed;
    if (s && s.date && s.phase !== 'allDone') {
      // 진행 중인 날짜의 기록이 바뀜 (확인·저장 목록·오류로 멈춘 상태 모두): 입력 목록은 그대로 두고 안내 + 저장 차단.
      // 아직 아무것도 입력하지 않은 '정하기' 단계면 그 날짜를 다시 불러옴. 서류 제출만 바뀐 것은 나이스와 무관
      const onDate = sessionDateChanges(diff, before, merged, s.date);
      if (onDate.length) {
        if (s.phase === 'prepare') reloadPrep = s;
        else s.remoteChanged = (s.remoteChanged || 0) + onDate.length;
      }
      shown -= onDate.length;
    }
    if (shown > 0) toast(`휴대폰에서 바뀐 기록 ${shown}건을 반영했습니다.`);
    render();
  } catch (e) {
    // 네트워크 오류 등은 다음 확인에서 다시 시도. 토큰 만료(401)는 drive.js가 토큰을 지우므로 다음부터 건너뜀
  } finally {
    S.checking = false;
    renderAutoCheck();
    if (reloadPrep && S.session === reloadPrep && reloadPrep.phase === 'prepare') {
      toast('휴대폰에서 이 날짜 기록이 바뀌어 다시 불러왔습니다.');
      goDate(reloadPrep.date);
    }
  }
}
let pollTimer = null;
let lastKick = 0;
function schedulePoll() {
  clearTimeout(pollTimer);
  pollTimer = null;
  if (!autoCheckOn() || document.hidden) return;
  pollTimer = setTimeout(async () => { pollTimer = null; await checkRemote(); schedulePoll(); }, pollMs());
}
// 패널이 다시 보이거나 포커스가 오면 바로 1회 확인 후 간격 재개 (겹치면 1회만)
function kickCheck() {
  if (!autoCheckOn() || document.hidden || Date.now() - lastKick < 1500) return;
  lastKick = Date.now();
  clearTimeout(pollTimer);
  pollTimer = null;
  checkRemote().finally(schedulePoll);
}
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { clearTimeout(pollTimer); pollTimer = null; } else kickCheck();
});
window.addEventListener('focus', kickCheck);
function autoCheckText() {
  const at = S.remote.lastCheckAt ? new Date(S.remote.lastCheckAt) : null;
  const hhmm = at ? `${String(at.getHours()).padStart(2, '0')}:${String(at.getMinutes()).padStart(2, '0')}` : '';
  return `자동 확인 켜짐 (${Math.max(1, Math.round(pollMs() / 1000))}초마다)${hhmm ? ` · 마지막 확인 ${hhmm}` : ''}`;
}
function renderAutoCheck() {
  const el = $('autoCheck');
  if (el) el.textContent = autoCheckText();
}
async function connectDrive() {
  S.drive.connected = true;
  await syncNow(true);
  if (!S.drive.lastSyncAt) { S.drive.connected = false; }
  await store.saveDriveState(S.drive);
  render();
}
async function disconnectDrive() {
  await drive.forgetToken();
  S.drive = { connected: false, lastSyncAt: null };
  await store.saveDriveState(S.drive);
  toast('구글 드라이브 연결을 해제했습니다. 이 PC의 기록은 남아 있습니다.');
  render();
}

// ---------- 백업 ----------
async function importBackup(file) {
  try {
    const obj = store.parseBackup(await file.text());
    S.data = mergeData(S.data, obj);
    await store.saveData(S.data);
    toast(`기록 ${obj.records.length}건을 가져왔습니다.`);
    scheduleSync();
  } catch (e) {
    toast(`가져오지 못했습니다. ${e.message}`, true);
  }
  render();
}
function exportBackup() {
  if (!S.data) { toast('내보낼 기록이 없습니다.'); return; }
  const blob = new Blob([JSON.stringify(S.data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  const d = new Date();
  a.href = URL.createObjectURL(blob);
  a.download = `attendance-data-${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}.json`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

// ---------- 화면 ----------
function switchTab(tab) { S.tab = tab; render(); }

function renderConn() {
  const c = S.conn;
  if (c.state === 'ok') {
    const cls = c.info.cls;
    const d = c.info.gridYmd || c.info.ymd;
    const where = [cls ? `${cls.grade}학년 ${cls.classNo}반` : '', d ? `${formatDateKo(d)} 화면` : ''].filter(Boolean).join(' · ');
    return `<section class="card conn is-ok" data-testid="conn"><span class="conn-dot"></span>
      <div class="conn-main"><div class="conn-title">나이스 화면 감지됨</div><div class="conn-meta num">${esc(where)}</div></div>
      <span class="badge badge-done">연결됨</span></section>`;
  }
  const extra = c.state === 'noscript'
    ? '화면을 연 뒤에도 이 안내가 보이면 나이스 페이지를 새로고침(F5)하세요.'
    : c.state === 'checking' ? '나이스 화면을 찾는 중입니다.' : '화면이 열리면 자동으로 연결됩니다.';
  return `<div class="alert alert-info" data-testid="conn">${icon('i-info')}<div class="alert-body">
    <strong class="alert-title">나이스 화면이 감지되지 않았습니다</strong>${esc(NEIS_GUIDE)}<div class="small muted">${esc(extra)}</div></div></div>`;
}

// 입력 중인 날짜와 나이스 화면 날짜가 다르면 빨간 경고
function dateMismatch() {
  const s = S.session;
  if (!s || !s.date || S.conn.state !== 'ok' || ['allDone', 'moving'].includes(s.phase)) return '';
  const d = S.conn.info.gridYmd || S.conn.info.ymd;
  if (!d || (d === s.date && (S.conn.info.ymd || d) === s.date)) return '';
  return `<div class="alert alert-block" role="alert" data-testid="date-mismatch">${icon('i-alert')}<div class="alert-body"><strong class="alert-title">나이스 날짜가 다릅니다</strong>
    나이스 화면은 ${esc(formatDateKo(d))}, 입력 중인 날짜는 ${esc(formatDateKo(s.date))}입니다. 이대로는 입력하지 않습니다.
    <div class="alert-actions"><button class="btn btn-secondary btn-sm" data-act="gotoDate">이 날짜로 이동</button></div></div></div>`;
}

function rosterMismatch() {
  if (!S.roster || S.conn.state !== 'ok' || !S.conn.info.cls) return '';
  const h = S.conn.info.cls;
  if (S.roster.grade && (S.roster.grade !== h.grade || S.roster.classNo !== h.classNo)) {
    return `<div class="alert alert-block" role="alert">${icon('i-alert')}<div class="alert-body"><strong class="alert-title">반이 다릅니다</strong>
      저장된 명단은 ${S.roster.grade}학년 ${S.roster.classNo}반, 나이스 화면은 ${h.grade}학년 ${h.classNo}반입니다. [명단] 탭에서 다시 불러오세요.</div></div>`;
  }
  return '';
}

// 직접 확인이 필요한 기록 (자동 입력에서 제외됨): 날짜·번호별 묶음
function exclGroups() {
  const m = new Map();
  for (const r of pendingRecords().filter(exclOf)) {
    const k = `${r.date}|${r.no}`;
    if (!m.has(k)) m.set(k, { date: r.date, no: r.no, recs: [], reason: exclOf(r).reason, message: exclOf(r).message });
    m.get(k).recs.push(r);
  }
  return [...m.values()];
}
function renderExcluded() {
  const g = exclGroups();
  if (!g.length) return '';
  const n = g.reduce((a, x) => a + x.recs.length, 0);
  const canGo = S.conn.state === 'ok';
  // 같은 날 기록이 2건 이상이면 기록마다 따로 [입력 완료로 표시] (나이스 값과 기록마다 맞는지 선생님이 확인)
  const recRow = (r) => `<div class="row-between" data-rec="${r.id}" style="gap:var(--sp-2);margin-top:var(--sp-2)"><span class="small">${esc(recordLine(r))}${r.reason ? ` · ${esc(r.reason)}` : ''}</span>
    <button class="btn btn-secondary btn-sm" data-act="exclDone" data-ids="${r.id}">입력 완료로 표시</button></div>`;
  return `<section class="card card-flush" data-testid="excl"><div class="card-head"><h2 class="card-title">직접 확인이 필요한 기록</h2><span class="small muted num">${n}건</span></div>
    <ul class="list">${g.map((x) => `<li class="list-row" data-no="${x.no}" data-date="${x.date}"><span class="list-no">${x.no}</span><div class="list-main">
      <div class="list-title">${esc(formatDateKo(x.date))} · ${esc(nameOf(x.no) || '이름 없음')} · ${x.recs.length > 1 ? `기록 ${x.recs.length}건` : esc(recordLine(x.recs[0]))}</div>
      <div class="list-meta danger-text">${esc(SKIP_LABEL[x.reason] || x.message || '자동 입력 실패')}</div>
      ${x.recs.length > 1 ? `<div class="list-meta">나이스 값이 기록마다 맞는지 보고 기록마다 표시하세요.</div>${x.recs.map(recRow).join('')}` : ''}
      <div class="btn-row" style="margin-top:var(--sp-2)">
        <button class="btn btn-secondary btn-sm" data-act="exclGoto" data-date="${x.date}" ${canGo ? '' : 'disabled'}>이 날짜로 이동</button>
        ${x.recs.length > 1 ? '' : `<button class="btn btn-secondary btn-sm" data-act="exclDone" data-ids="${x.recs[0].id}">입력 완료로 표시</button>`}</div></div></li>`).join('')}</ul>
    <div class="items-foot small muted">나이스에서 직접 입력하고 [저장]한 뒤 [입력 완료로 표시]를 누르세요. 자동 입력은 이 기록들을 건너뜁니다.</div></section>`;
}
async function exclGoto(date) {
  try { await cmd('setDate', { date }); toast(`${formatDateKo(date)}로 이동했습니다 (조회만).`); }
  catch (e) { toast(e.message, true); }
  detect();
}
async function exclDone(ids) {
  const set = new Set(ids);
  await commitData((data, now) => { for (const r of data.records) if (set.has(r.id)) neisDone(r, now); });
  await pruneExcl();
  toast(`기록 ${ids.length}건을 입력 완료로 표시했습니다.`);
  render();
}

function renderPendingList() {
  const recs = autoRecords();
  let html = '';
  if (S.notice) {
    html += `<div class="alert alert-info" data-testid="notice">${icon('i-info')}<div class="alert-body">${esc(S.notice)}
      <div class="alert-actions"><button class="btn btn-ghost btn-sm" data-act="dismissNotice">닫기</button></div></div></div>`;
  }
  if (!S.data) {
    return html + `<div class="card"><div class="empty">${icon('i-list')}<div class="empty-title">가져온 기록이 없습니다</div>
      <div class="empty-text">[설정]에서 구글 드라이브를 연결하거나 앱에서 내보낸 백업 파일을 가져오세요.</div>
      <button class="btn btn-secondary btn-sm" data-act="tab" data-tab="settings">설정으로 가기</button></div></div>`;
  }
  html += renderExcluded();
  if (!recs.length) {
    return html + `<div class="card"><div class="empty">${icon('i-check')}<div class="empty-title">자동으로 입력할 기록이 없습니다</div>
      <div class="empty-text">${exclGroups().length ? '위의 직접 확인이 필요한 기록만 남았습니다.' : '모든 기록이 입력 완료 상태입니다.'}</div></div></div>`;
  }
  const dates = autoDates();
  const groups = dates.map((d) => {
    const items = recs.filter((r) => r.date === d);
    const rows = items.map((r) => {
      const why = blockReason(r);
      return `<li class="list-row"><span class="list-no">${r.no}</span><div class="list-main">
        <div class="list-title">${esc(nameOf(r.no) || '이름 없음')} · ${esc(recordLine(r))}</div>
        ${r.reason ? `<div class="list-meta">${esc(r.reason)}</div>` : ''}</div>
        ${why ? '<span class="badge badge-missing">정할 것 있음</span>' : '<span class="badge badge-neis-wait">대기</span>'}</li>`;
    }).join('');
    return `<div class="list-group-head"><span>${esc(formatDateKo(d))}</span><span class="num">${items.length}건</span></div><ul class="list">${rows}</ul>`;
  }).join('');
  return html + `<section class="card card-flush" data-testid="pending"><div class="card-head"><h2 class="card-title">나이스 미입력 기록</h2>
    <span class="small muted num">${dates.length}일 · ${recs.length}건</span></div>${groups}</section>
    <div class="alert alert-info">${icon('i-info')}<div class="alert-body">[나이스 입력 시작]을 누르면 가장 이른 날짜부터 학생들을 자동으로 입력합니다.
      날짜마다 입력 내용을 확인한 뒤 [확인 완료 · 저장]을 누르면 저장하고 다음 날짜로 넘어갑니다.</div></div>`;
}

const ITEM_BADGE = {
  wait: ['badge-neis-wait', '대기'], current: ['badge-info', '입력 중'], done: ['badge-done', '입력됨'],
  skipped: ['badge-missing', '제외'], error: ['badge-missing', '확인 필요'],
};
const PHASE_TEXT = {
  moving: '나이스 날짜를 바꾸는 중입니다', prepare: '입력 전에 정할 것이 있습니다', auto: '학생들을 자동으로 입력하는 중입니다',
  review: '나이스 표를 확인해 주세요', plan: '바뀐 내용을 확인하고 저장하세요', saving: '나이스에 저장하는 중입니다',
  saveCheck: '저장 전에 다른 기기의 변경을 확인하는 중입니다', reloadAsk: '나이스 확인창을 기다리는 중입니다',
  error: '멈췄습니다', allDone: '모든 날짜를 입력했습니다', reapply: '나이스 표를 다시 불러오는 중입니다',
};

function renderPrepare(s) {
  const recs = s.prep.ids.map((id) => S.data.records.find((r) => r.id === id)).filter(Boolean);
  return `<section class="card stack" data-testid="prepare"><div><h2 class="card-title">구분·사유 정하기</h2>
    <p class="small muted" style="margin:4px 0 0">나이스에는 '미정'이 없고, 기타는 사유가 있어야 저장됩니다. 정하면 앱 기록도 바뀝니다.</p></div>
    ${recs.map((r) => {
      const d = s.prep.draft[r.id];
      return `<div class="stack-sm" data-prep="${r.id}"><div class="row"><span class="list-no">${r.no}</span>
        <div class="list-main"><div class="list-title">${esc(nameOf(r.no) || '이름 없음')} · ${esc(KINDS[r.kind].ko)}${r.period ? ` ${r.period}교시` : ''}${r.periods && r.periods.length ? ` ${r.periods.join(', ')}교시` : ''}</div>
        <div class="list-meta danger-text">${esc(blockReason(r) || '')}</div></div></div>
        <div class="seg" role="radiogroup" aria-label="${r.no}번 구분">${orderedNeisDivs(S.data && S.data.settings).map((dv) =>
          `<button class="seg-item" role="radio" aria-checked="${d.div === dv}" data-act="prepDiv" data-id="${r.id}" data-div="${dv}">${esc(DIVS[dv].ko)}</button>`).join('')}</div>
        <input class="input" data-prep-reason="${r.id}" placeholder="사유${d.div === 'etc' ? ' (기타는 필수)' : ''}" value="${esc(d.reason)}" aria-label="${r.no}번 사유"></div>`;
    }).join('')}</section>`;
}

function renderItems(s) {
  const byNo = new Map((s.review || []).map((r) => [r.no, r]));
  const rows = s.items.map((it) => {
    const row = byNo.get(it.no);
    let [cls, label] = ITEM_BADGE[it.status] || ITEM_BADGE.wait;
    if (it.status === 'done' && it.warnings.length) [cls, label] = ['badge-info', '경고 확인'];
    const changed = row && it.status === 'done' && recordDiffs(it.rec, reverseMap(row)).length;
    if (changed || (row && it.status === 'done' && !row.gb)) [cls, label] = ['badge-info', '나이스에서 수정됨'];
    const why = it.status === 'skipped' || it.status === 'error' ? (SKIP_LABEL[it.reason] || it.message || '입력 실패') : '';
    const ed = s.edits && s.edits[it.ids[0]];
    const canEdit = s.phase === 'review' && !it.manual && !s.editor;
    return `<li class="list-row${it.status === 'current' ? ' is-current' : ''}" data-no="${it.no}"><span class="list-no">${it.no}</span>
      <div class="list-main"><div class="list-title">${esc(it.name || '이름 없음')} · ${esc(it.recs.map(recordLine).join(' + '))}</div>
      ${row ? `<div class="list-meta">나이스: ${esc(describeRow(row))}</div>` : ''}
      ${why ? `<div class="list-meta danger-text">${esc(why)}</div>` : ''}
      ${it.warnings.length ? `<div class="list-meta">${esc(it.warnings.join(' / '))}</div>` : ''}
      ${ed ? `<div class="list-meta strong edit-note" data-testid="edit-note">${esc(editLabel(ed))}</div>` : ''}</div>
      <div class="list-side"><span class="badge ${cls}" data-status="${it.status}">${label}</span>
      ${canEdit ? `<button class="btn btn-secondary btn-sm" data-act="editRow" data-no="${it.no}">수정</button>` : ''}</div></li>`;
  });
  for (const [key, e] of Object.entries(s.edits || {})) {
    if (e.type !== 'add') continue;
    rows.push(`<li class="list-row" data-no="${e.no}"><span class="list-no">${e.no}</span><div class="list-main">
      <div class="list-title">${esc(nameOf(e.no))} · 새 기록</div><div class="list-meta strong edit-note" data-testid="edit-note">${esc(editLabel(e))}</div></div>
      <div class="list-side">${s.phase === 'review' && !s.editor ? `<button class="btn btn-secondary btn-sm" data-act="editAdd" data-key="${key}">수정</button>` : ''}</div></li>`);
  }
  // 앱 기록에 없는데 나이스에서 바뀐 행
  const nos = new Set(s.items.map((it) => it.no));
  for (const row of s.review || []) {
    if (!row.dirty || nos.has(row.no) || (s.baseline && s.baseline.get(row.no) === row.sig)) continue;
    rows.push(`<li class="list-row" data-no="${row.no}"><span class="list-no">${row.no}</span><div class="list-main">
      <div class="list-title">${esc(row.name)} · 앱 기록 없음</div><div class="list-meta">나이스: ${esc(describeRowFull(row))}</div></div>
      <span class="badge badge-info">나이스에서 바뀜</span></li>`);
  }
  return `<section class="card card-flush" data-testid="items"><div class="list-group-head"><span>${esc(formatDateKo(s.date))}</span><span class="num">${s.items.length}명</span></div>
    <ul class="list">${rows.join('')}</ul>
    ${s.phase === 'review' && !s.editor ? '<div class="items-foot"><button class="btn btn-secondary btn-sm" data-act="addStudent">학생 추가</button></div>' : ''}</section>`;
}

function renderPlan(s) {
  const P = s.plan;
  const nameFor = (row, it) => (it && it.name) || row.name || '';
  if (P.reverted.length) {
    // 행 상태가 '변경 없음'으로 돌아감 = 나이스 [조회] 등으로 되돌려짐. 앱 기록 삭제 선택지는 보여 주지 않음
    return `<div class="alert alert-block" role="alert" data-testid="plan-reverted">${icon('i-alert')}<div class="alert-body"><strong class="alert-title">나이스 표가 되돌려졌습니다</strong>
      ${P.reverted.map((n) => `${n}번`).join(', ')} 학생의 입력이 나이스에서 저장 전 상태로 돌아가 있습니다(나이스 [조회]를 누른 경우). 저장하지 않았고 앱 기록도 그대로입니다. 다시 입력할까요?
      <div class="alert-actions"><button class="btn btn-primary btn-sm" data-act="redoDate">다시 입력</button><button class="btn btn-secondary btn-sm" data-act="stop">멈추기</button></div></div></div>`;
  }
  let html = '';
  const blockLine = (b) => `<div class="small" data-testid="blocked-row" data-no="${b.row.no}"><span class="strong">${b.row.no}번 ${esc(nameFor(b.row, b.it))}</span> · 나이스: ${esc(describeRowFull(b.row))}${b.why ? `<div class="tiny">${esc(b.why)}</div>` : ''}</div>`;
  const outside = P.blocked.filter((b) => !b.entered);
  const ignored = P.entries.filter((e) => e.type === 'added' && e.choice === 'ignore');
  if (outside.length || ignored.length) {
    html += `<div class="alert alert-block" role="alert" data-testid="plan-blocked">${icon('i-alert')}<div class="alert-body"><strong class="alert-title">확장프로그램이 입력하지 않은 칸이 바뀌어 있습니다</strong>
      나이스에서 그 칸을 되돌리거나 [조회]로 처음부터 다시 하세요. 되돌린 뒤 ${kbd('돌아가기')} → ${kbd('확인 완료 · 저장')}을 다시 누르면 됩니다. 그 전에는 저장하지 않습니다.
      <div class="stack-sm" style="margin-top:var(--sp-2)">${outside.map(blockLine).join('')}${ignored.map((e) => blockLine({ row: e.row, it: null, why: '[무시]를 골랐습니다. 나이스에서 이 행을 되돌려야 저장할 수 있습니다.' })).join('')}</div></div></div>`;
  }
  const invalid = P.blocked.filter((b) => b.entered);
  if (invalid.length) {
    html += `<div class="alert alert-block" role="alert" data-testid="plan-invalid">${icon('i-alert')}<div class="alert-body"><strong class="alert-title">확인이 필요한 행이 있어 저장하지 않습니다</strong>
      나이스에서 그 학생 값을 고치거나 [조회]로 처음부터 다시 하세요.
      <div class="stack-sm" style="margin-top:var(--sp-2)">${invalid.map(blockLine).join('')}</div></div></div>`;
  }
  const e = P.entries;
  const line = (en) => {
    const no = en.row.no;
    let body = '', choice = '', extra = '';
    if (en.type === 'same') body = `그대로 저장 · ${esc(describeRow(en.row))}`;
    else if (en.type === 'update') body = `앱 기록 수정: ${en.diffs.map(esc).join(' / ')}`;
    else if (en.type === 'deleted') {
      body = `나이스에서 지워짐 · 앱 기록: ${esc(recordLine(en.it.rec))}`;
      choice = [['delete', '앱 기록 삭제'], ['keep', '앱 기록 남기고 자동 입력에서 빼기']].map(([v, t]) =>
        `<button class="seg-item" role="radio" aria-checked="${en.choice === v}" data-act="planChoice" data-no="${no}" data-v="${v}">${t}</button>`).join('');
    } else if (en.type === 'added') {
      body = `앱에 없는 기록 · 나이스: ${esc(describeRow(en.row))}`;
      choice = [['add', '앱에 추가'], ['ignore', '무시']].map(([v, t]) =>
        `<button class="seg-item" role="radio" aria-checked="${en.choice === v}" data-act="planChoice" data-no="${no}" data-v="${v}">${t}</button>`).join('');
      if (en.choice === 'ignore') extra += '<div class="list-meta danger-text">무시하면 저장할 수 없습니다. 나이스에서 이 행을 되돌린 뒤 다시 확인하세요.</div>';
    }
    if (en.warns && en.warns.length && !(en.type === 'added' && en.choice === 'ignore')) {
      const absent = en.parsed && en.parsed.kind === 'absent';
      extra += `<div class="list-meta danger-text" data-testid="mark-warn">기대값과 다름: ${en.warns.map(esc).join(' / ')}${absent ? ' (결석의 실제 자동 표시 형태는 아직 확인되지 않았습니다)' : ''}</div>
        <label class="check"><input type="checkbox" data-ack="${no}" ${en.ack ? 'checked' : ''}><span class="check-box"></span><span class="check-label small">나이스 표를 직접 보고 확인함</span></label>`;
    }
    return `<li class="list-row plan-row" data-no="${no}" data-type="${en.type}"><span class="list-no">${no}</span><div class="list-main">
      <div class="list-title">${esc(nameFor(en.row, en.it))}</div><div class="list-meta wrap">${body}</div>${extra}
      ${choice ? `<div class="seg seg-sm" role="radiogroup">${choice}</div>` : ''}</div></li>`;
  };
  const left = s.items.filter((it) => !e.some((en) => en.it === it));
  return html + `<section class="card card-flush" data-testid="plan"><div class="card-head"><h2 class="card-title">저장할 내용</h2><span class="small muted num">${e.length}명</span></div>
    ${e.length ? `<ul class="list">${e.map(line).join('')}</ul>` : '<div class="empty"><div class="empty-text">나이스에서 바뀐 행이 없습니다. 저장 없이 다음 날짜로 넘어갑니다.</div></div>'}</section>
    ${left.length ? `<div class="alert alert-info">${icon('i-info')}<div class="alert-body">저장 뒤에도 미입력으로 남는 학생: ${left.map((it) => `${it.no}번(${esc(SKIP_LABEL[it.reason] || it.message || '입력 안 됨')})`).join(', ')}</div></div>` : ''}`;
}

function renderSession() {
  const s = S.session;
  let html = `<section class="card stack-sm" data-testid="progress"><div class="row-between">
    <span class="strong">${s.date ? `${esc(formatDateKo(s.date))} · ` : ''}${esc(PHASE_TEXT[s.phase] || '')}</span>
    <span class="small muted num">${s.finished.length ? `끝낸 날짜 ${s.finished.length}일` : ''}</span></div>`;
  if (s.phase === 'auto') {
    const n = s.items.length, k = s.items.filter((it) => !['wait', 'current'].includes(it.status)).length;
    html += `<div class="progress" role="progressbar" aria-valuenow="${k}" aria-valuemin="0" aria-valuemax="${n}"><span style="width:${n ? Math.round((k / n) * 100) : 0}%"></span></div>`;
  }
  html += '</section>';
  html += `<div class="callout" data-testid="callout" data-phase="${s.phase}">`;
  if (s.phase === 'review') {
    html += editCount(s)
      ? `<div class="callout-who">고친 내용 ${editCount(s)}건이 있습니다</div><div class="callout-what">${kbd('수정 반영 후 다시 입력')}을 누르면 앱 기록을 고치고, 나이스 [조회]로 이 날짜를 다시 불러온 뒤 처음부터 다시 입력합니다.</div>`
      : `<div class="callout-who">나이스 표를 확인해 주세요</div><div class="callout-what">입력한 행은 파란색, 확인이 필요한 행은 빨간색으로 표시했습니다. 고칠 학생은 아래 목록의 ${kbd('수정')}으로 고치세요. 나이스 팝업에서 직접 고쳐도 되며, 그 뒤 ${kbd('다시 읽기')}를 누르세요.</div>
      <div class="callout-do">다 확인했으면 ${kbd('확인 완료 · 저장')}</div>`;
  } else if (s.phase === 'plan') {
    html += `<div class="callout-who">이대로 저장할까요?</div><div class="callout-what">나이스 표의 최종값을 앱 기록에 반영하고 나이스 [저장]을 누릅니다.</div>`;
  } else if (s.phase === 'allDone') {
    html += `<div class="callout-who">모든 날짜를 입력했습니다</div><div class="callout-what">${s.finished.map((f) => `${formatDateKo(f.date)} ${f.count}건`).join(', ') || '저장한 날짜 없음'}</div>`;
  } else if (s.phase === 'error') {
    html += `<div class="callout-who">멈췄습니다</div>`;
  } else if (s.phase === 'saving') {
    html += `<div class="callout-who">${esc(PHASE_TEXT.saving)}</div><div class="callout-what">나이스가 저장을 끝낼 때까지 기다려 주세요. 나이스 [저장]을 누른 뒤에는 멈출 수 없습니다.</div>`;
  } else if (s.phase === 'reloadAsk') {
    html += `<div class="callout-who">나이스 확인창에서 직접 선택해 주세요</div><div class="callout-what">확장프로그램은 이 확인창의 버튼을 누르지 않습니다.</div>`;
  } else {
    html += `<div class="callout-who">${esc(PHASE_TEXT[s.phase] || '')}</div><div class="callout-what">언제든 ${kbd('멈추기')}를 누를 수 있습니다. 멈추면 그 날짜는 저장되지 않습니다.</div>`;
  }
  html += '</div>';
  if (s.phase === 'error') {
    const neisMsg = ['neis_alert', 'neis_confirm'].includes(s.errorCode);
    const afterConfirm = s.errorData && s.errorData.afterConfirm && s.errorCode !== 'saved_maybe';
    const note = afterConfirm
      ? '나이스 [저장] 확인 뒤에 생긴 일이라 저장됐는지 확장프로그램이 확인하지 못했습니다. 나이스 알림을 닫고 [조회]로 표 값을 직접 확인하세요. 앱 기록은 입력 완료로 표시하지 않았습니다.'
      : neisMsg ? '나이스 알림창을 닫은 뒤 다시 시도하세요. 저장되지 않았습니다.' : '';
    html += `<div class="alert alert-block" role="alert" data-testid="error">${icon('i-alert')}<div class="alert-body">
      <strong class="alert-title">${neisMsg ? '나이스 알림' : '확인이 필요합니다'}</strong><span class="pre">${esc(s.error)}</span>
      ${s.errorCode === 'date_changed' ? '<div class="alert-actions"><button class="btn btn-secondary btn-sm" data-act="gotoDate">이 날짜로 이동</button></div>' : ''}
      ${note ? `<div class="small">${esc(note)}</div>` : ''}</div></div>`;
  }
  if (s.phase === 'reloadAsk') {
    html += `<div class="alert alert-block" role="alert" data-testid="reload-ask">${icon('i-alert')}<div class="alert-body"><strong class="alert-title">나이스 확인창</strong>
      <span class="pre" data-testid="reload-ask-msg">${esc(s.reloadDialog)}</span>
      <div class="small" style="margin-top:var(--sp-2)">[조회]를 눌렀더니 위 확인창이 떴습니다. 확장프로그램은 이 확인창의 어떤 버튼도 누르지 않습니다. 나이스 확인창에서 직접 선택해 주세요. 저장하지 않고 다시 불러온다는 뜻이 확실할 때만 진행하고, 뜻을 모르겠으면 나이스에서 [취소]를 누른 뒤 ${kbd('멈추기')}를 누르세요.</div>
      <div class="small">나이스 표가 다시 불러와진 것(날짜 일치, 모든 행 변경 없음)을 확인한 뒤에만 다시 입력합니다. 그 사이 저장된 것으로 보이면 다시 입력하지 않고 멈춥니다.</div></div></div>`;
  }
  if (['review', 'plan', 'error'].includes(s.phase) && s.remoteChanged) {
    const canRedo = s.phase !== 'error';
    html += `<div class="alert alert-block" role="alert" data-testid="remote-changed">${icon('i-alert')}<div class="alert-body"><strong class="alert-title">다른 기기에서 이 날짜 기록이 바뀌었습니다</strong>
      휴대폰에서 바뀐 ${formatDateKo(s.date)} 기록 ${s.remoteChanged}건이 지금 입력한 내용에 반영되지 않았습니다. ${kbd('다시 불러와 다시 입력')}을 누르면 나이스 [조회]로 이 날짜를 다시 불러온 뒤 바뀐 기록대로 다시 입력합니다. 그 전에는 저장할 수 없습니다.
      ${canRedo ? '<div class="alert-actions"><button class="btn btn-primary btn-sm" data-act="remoteRedo">다시 불러와 다시 입력</button></div>' : '<div class="small">먼저 위 문제를 해결하고 이어서 진행하면 이 버튼이 나옵니다.</div>'}</div></div>`;
  }
  if (s.phase === 'review' && s.warnDirect && s.warnDirect.length) {
    html += `<div class="alert alert-block" role="alert" data-testid="warn-direct">${icon('i-alert')}<div class="alert-body"><strong class="alert-title">나이스에서 직접 고친 내용이 지워집니다</strong>
      ${s.warnDirect.join(', ')}번 행은 나이스에서 직접 바뀐 값입니다. [수정 반영]은 나이스 [조회]로 이 날짜를 다시 불러오므로 이 값이 지워지고, 앱 기록대로 다시 입력됩니다. 남기려면 그 학생도 [수정]으로 고쳐 두세요.
      <div class="alert-actions"><button class="btn btn-danger-outline btn-sm" data-act="applyEdits" data-force="1">그래도 수정 반영</button></div></div></div>`;
  }
  if (s.phase === 'review' && s.editor) html += renderEditor(s);
  if (s.phase === 'prepare') html += renderPrepare(s);
  if (s.phase === 'plan') html += renderPlan(s);
  if ((s.items.length || s.phase === 'review') && s.phase !== 'plan') html += renderItems(s);
  if (s.finished.length && s.phase !== 'allDone') {
    html += `<div class="small muted" data-testid="finished">끝낸 날짜: ${s.finished.map((f) => `${esc(formatDateKo(f.date))} ${f.saved ? `${f.count}건` : '변경 없음'}`).join(', ')}</div>`;
  }
  return html;
}

function footerFor() {
  const s = S.session;
  if (S.tab !== 'neis') return '';
  const b = (act, label, cls, disabled) => `<button class="btn ${cls}" data-act="${act}" ${disabled ? 'disabled' : ''}>${label}</button>`;
  if (!s) {
    if (!S.data || !autoRecords().length) return '';
    return b('startRun', '나이스 입력 시작', 'btn-primary', S.conn.state !== 'ok');
  }
  switch (s.phase) {
    case 'moving': case 'auto': case 'saveCheck': case 'reloadAsk':
      return b('stop', '멈추기', 'btn-secondary');
    case 'saving':
      return b('none', '저장 중에는 멈출 수 없습니다', 'btn-secondary', true);
    case 'prepare':
      return b('stop', '멈추기', 'btn-secondary') + b('prepSkip', '이 기록 빼기', 'btn-secondary') + b('prepDone', '정하고 입력 시작', 'btn-primary');
    case 'review':
      if (editCount(s)) return b('discardEdits', '수정 취소', 'btn-secondary', !!s.editor) + b('applyEdits', '수정 반영 후 다시 입력', 'btn-primary', !!s.editor);
      return b('stop', '멈추기', 'btn-secondary') + b('reread', '다시 읽기', 'btn-secondary') + b('confirmSave', '확인 완료 · 저장', 'btn-primary', !!s.editor || !!s.remoteChanged);
    case 'reapply':
      return b('stop', '멈추기', 'btn-secondary');
    case 'plan':
      return b('backReview', '돌아가기', 'btn-secondary') + b('doSave', '이대로 저장', 'btn-primary', !!planIssue(s.plan) || !!s.remoteChanged);
    case 'error':
      if (s.errorAt === 'savedMaybe') return b('stop', '멈추기', 'btn-primary');
      return b('stop', '멈추기', 'btn-secondary') + b('resume', s.errorAt === 'auto' ? '이어서 입력' : s.errorAt === 'date' ? '다시 시도' : '다시 읽기', 'btn-primary');
    case 'allDone':
      return b('stop', '목록으로', 'btn-primary');
    default: return '';
  }
}

function renderNeis() {
  let html = renderConn() + rosterMismatch() + dateMismatch();
  if (!S.session && S.data && !rosterList().length) {
    html += `<div class="alert alert-info">${icon('i-user')}<div class="alert-body">학생 이름을 표시하려면 [명단] 탭에서 나이스 명단을 먼저 불러오세요.
      <div class="alert-actions"><button class="btn btn-secondary btn-sm" data-act="tab" data-tab="roster">명단 불러오기</button></div></div></div>`;
  }
  html += S.session ? renderSession() : renderPendingList();
  html += `<details class="log" ${S.logOpen ? 'open' : ''} id="logBox"><summary>작업 기록 보기</summary><ul class="log-lines" id="logLines"></ul></details>`;
  return html;
}

function renderRoster() {
  const r = S.roster;
  const canRead = S.conn.state === 'ok' && !S.session;
  let html = `<section class="card stack-sm"><h2 class="card-title">나이스 명단</h2>
    <p class="small muted" style="margin:0">나이스 출결 표에서 번호와 이름만 읽어 이 PC에 저장합니다. 구글 드라이브에 연결되어 있으면 앱 전용 폴더에도 올려 휴대폰 앱에서 이름으로 검색할 수 있게 합니다.</p>
    <button class="btn btn-primary btn-block" data-act="roster" ${canRead && !S.rosterBusy ? '' : 'disabled'}>${S.rosterBusy ? '불러오는 중' : '나이스에서 명단 불러오기'}</button>
    ${S.conn.state !== 'ok' ? `<div class="small muted">${esc(NEIS_GUIDE)}</div>` : ''}</section>`;
  if (showUploadPrompt()) {
    html += `<section class="card stack-sm" data-testid="roster-upload-prompt"><h2 class="card-title">휴대폰 앱에서도 이름으로 검색</h2>
      <p class="small" style="margin:0">이 PC의 명단 ${S.roster.students.length}명을 구글 드라이브에 올리면 휴대폰 앱에서도 이름으로 검색할 수 있습니다.</p>
      <div class="btn-row"><button class="btn btn-primary btn-sm" data-act="rosterUpload">드라이브에 올리기</button><button class="btn btn-secondary btn-sm" data-act="rosterLater">나중에</button></div></section>`;
  }
  if (S.rosterConfirm) {
    const rc = S.rosterConfirm;
    html += `<section class="card stack-sm" data-testid="roster-confirm"><h2 class="card-title">학년·반을 확인해 주세요</h2>
      <p class="small" style="margin:0">나이스 화면에서 학년·반을 읽지 못했습니다. 지금 나이스에 열려 있는 반이 맞는지 확인한 뒤 저장하세요. (${rc.students.length}명)</p>
      <div class="field-row"><input class="input num" id="rcGrade" inputmode="numeric" aria-label="학년" value="${esc(rc.grade)}"><span class="small" style="align-self:center">학년</span>
      <input class="input num" id="rcClass" inputmode="numeric" aria-label="반" value="${esc(rc.classNo)}"><span class="small" style="align-self:center">반</span></div>
      <div class="btn-row"><button class="btn btn-primary btn-sm" data-act="confirmRoster">이 반이 맞습니다</button><button class="btn btn-secondary btn-sm" data-act="cancelRoster">취소</button></div></section>`;
  }
  if (r && r.students.length) {
    html += `<section class="card card-flush" data-testid="roster"><div class="card-head"><h2 class="card-title">${r.grade ? `${r.grade}학년 ${r.classNo}반` : '명단'} · <span class="num">${r.students.length}명</span></h2>
      <span class="tiny muted num">${esc(fmtTime(r.importedAt))} 불러옴</span></div>
      <ul class="list roster-grid">${r.students.map((s) => `<li class="list-row"><span class="list-no">${s.no}</span><div class="list-main"><div class="list-title">${esc(s.name)}</div></div></li>`).join('')}</ul></section>
      <button class="btn btn-danger-outline btn-sm" data-act="clearRoster">이 PC에서 명단 지우기</button>`;
  } else if (usingFallback()) {
    const dr = S.data.roster;
    html += `<div class="alert alert-info" data-testid="roster-fallback">${icon('i-info')}<div class="alert-body">앱에서 등록한 명단을 쓰는 중입니다. 나이스에서 불러오면 더 정확합니다.</div></div>
      <section class="card card-flush" data-testid="roster-drive"><div class="card-head"><h2 class="card-title">앱 명단 · <span class="num">${dr.students.length}명</span></h2>
      <span class="tiny muted num">${esc(fmtTime(dr.updatedAt))} 갱신</span></div>
      <ul class="list roster-grid">${dr.students.map((s) => `<li class="list-row"><span class="list-no">${s.no}</span><div class="list-main"><div class="list-title">${esc(s.name)}</div></div></li>`).join('')}</ul></section>`;
  } else {
    html += `<div class="card"><div class="empty">${icon('i-user')}<div class="empty-title">저장된 명단이 없습니다</div>
      <div class="empty-text">나이스 일일출결관리(담임용) 화면을 연 뒤 위 버튼을 누르세요.</div></div></div>`;
  }
  // 드라이브의 명단까지 지우기 (확인 뒤 이 PC와 드라이브 모두)
  if (S.rosterClearAsk) {
    html += `<div class="alert alert-block" role="alertdialog" data-testid="roster-clear-confirm">${icon('i-alert')}<div class="alert-body"><strong class="alert-title">명단을 모두 지울까요?</strong>
      이 PC의 나이스 명단과 구글 드라이브의 학생 명단이 지워집니다. 휴대폰 앱에서도 이름이 사라집니다. 출결 기록은 그대로입니다.
      <div class="alert-actions"><button class="btn btn-secondary btn-sm" data-act="clearAllCancel">취소</button><button class="btn btn-danger btn-sm" data-act="clearAllOk">모두 지우기</button></div></div></div>`;
  } else if (driveRosterOn() || localRosterOn()) {
    html += `<button class="btn btn-danger-outline btn-sm" data-act="clearAllAsk" data-testid="roster-clear-all">이 PC와 드라이브의 명단 모두 지우기</button>`;
  }
  return html;
}

function renderSettings() {
  const hasId = drive.hasClientId();
  const recs = S.data ? S.data.records : [];
  const pend = pendingRecords().length;
  let g = `<section class="card stack-sm"><h2 class="card-title">구글 드라이브 연결</h2>`;
  if (!hasId) {
    g += `<div class="alert alert-info">${icon('i-info')}<div class="alert-body">구글 연결을 쓰려면 확장 폴더의 <b>config.js</b>에 GOOGLE_CLIENT_ID를 넣어야 합니다. 설정 전에는 아래 백업 파일로 기록을 가져올 수 있습니다.</div></div>`;
  } else {
    g += `<div class="small">${S.drive.connected ? `연결됨${S.drive.lastSyncAt ? ` · 마지막 동기화 ${esc(fmtTime(S.drive.lastSyncAt))}` : ''}` : '연결되지 않음'}</div>
      ${S.drive.connected ? `<div class="tiny muted num" id="autoCheck" data-testid="auto-check">${esc(autoCheckText())}</div>` : ''}
      <div class="btn-row">${S.drive.connected
        ? `<button class="btn btn-primary btn-sm" data-act="sync" ${S.syncing ? 'disabled' : ''}>${S.syncing ? '동기화 중' : '지금 동기화'}</button><button class="btn btn-secondary btn-sm" data-act="disconnect">연결 해제</button>`
        : `<button class="btn btn-primary btn-sm" data-act="connect" ${S.syncing ? 'disabled' : ''}>구글 연결</button>`}</div>`;
  }
  g += `<div class="field"><label class="label" for="redir">리디렉션 URI (구글 클라우드 설정에 붙여넣기)</label>
    <div class="field-row"><input class="input num" id="redir" readonly value="${esc(drive.redirectUrl())}"><button class="btn btn-secondary btn-sm" data-act="copyRedir">복사</button></div></div></section>`;
  const b = `<section class="card stack-sm"><h2 class="card-title">백업 파일</h2>
    <p class="small muted" style="margin:0">앱에서 내보낸 JSON 파일을 가져오면 이 PC의 기록과 합칩니다. 같은 기록은 더 최근에 고친 쪽을 남깁니다.</p>
    <div class="small num" data-testid="data-summary">기록 ${recs.length}건 · 나이스 미입력 ${pend}건</div>
    ${driveRosterOn() ? '<div class="tiny muted" data-testid="backup-names-note">백업 파일에는 학생 이름이 들어 있습니다. 외부에 공유하지 마세요.</div>' : ''}
    <div class="btn-row"><button class="btn btn-secondary btn-sm" data-act="import">백업 파일 가져오기</button>
    <button class="btn btn-secondary btn-sm" data-act="export" ${S.data ? '' : 'disabled'}>내보내기</button></div></section>`;
  return g + b;
}

function renderLog() {
  const ul = $('logLines');
  if (!ul) return;
  ul.innerHTML = S.logs.length
    ? S.logs.slice(-80).map((l) => {
      const d = new Date(l.at);
      const t = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
      return `<li class="${l.level === 'warn' ? 'is-warn' : l.level === 'error' ? 'is-error' : ''}"><span class="num">${t}</span> ${esc(l.msg)}</li>`;
    }).join('')
    : '<li>기록이 없습니다.</li>';
  ul.scrollTop = ul.scrollHeight;
}

function render() {
  document.querySelectorAll('.panel-tab').forEach((t) => t.setAttribute('aria-selected', String(t.dataset.tab === S.tab)));
  const body = $('body');
  const y = body.parentElement.scrollTop;
  body.innerHTML = S.tab === 'neis' ? renderNeis() : S.tab === 'roster' ? renderRoster() : renderSettings();
  const f = footerFor();
  $('footer').innerHTML = f;
  $('footer').hidden = !f;
  $('btnSync').setAttribute('aria-busy', String(S.syncing));
  const lb = $('logBox');
  if (lb) lb.addEventListener('toggle', () => { S.logOpen = lb.open; });
  renderLog();
  body.parentElement.scrollTop = y;
}

// ---------- 이벤트 ----------
document.addEventListener('click', async (e) => {
  const tabBtn = e.target.closest('.panel-tab');
  if (tabBtn) { switchTab(tabBtn.dataset.tab); return; }
  const el = e.target.closest('[data-act]');
  if (!el || el.disabled) return;
  const act = el.dataset.act;
  const s = S.session;
  switch (act) {
    case 'tab': switchTab(el.dataset.tab); break;
    case 'startRun': startRun(); break;
    case 'exclGoto': if (!S.session) exclGoto(el.dataset.date); break;
    case 'exclDone': if (!S.session) exclDone(el.dataset.ids.split(',')); break;
    case 'stop': stopSession(); break;
    case 'dismissNotice': S.notice = null; render(); break;
    case 'gotoDate': gotoSessionDate(); break;
    case 'resume': if (s) resumeAfterError(); break;
    case 'prepDiv': if (s && s.prep) { s.prep.draft[el.dataset.id].div = el.dataset.div; render(); } break;
    case 'prepDone': if (s && s.prep) finishPrepare(); break;
    case 'prepSkip': if (s && s.prep) skipPrepare(); break;
    case 'reread': if (s) enterReview(); break;
    case 'confirmSave': if (s && s.phase === 'review' && !editCount(s) && !s.editor && !s.remoteChanged) buildPlan(); break;
    case 'remoteRedo': if (s && (s.phase === 'review' || s.phase === 'plan') && s.remoteChanged) {
      s.phase = 'review'; s.plan = null; s.editor = null;
      applyEdits(false);
    } break;
    case 'editRow': if (s && s.phase === 'review') { const it = s.items.find((x) => x.no === Number(el.dataset.no)); if (it) openEditor(s, 'edit', it); } break;
    case 'editAdd': if (s && s.phase === 'review') { const e = s.edits[el.dataset.key]; if (e) openEditor(s, 'edit', { addKey: el.dataset.key, no: e.no, rec: e.fields, ids: [] }); } break;
    case 'addStudent': if (s && s.phase === 'review') openEditor(s, 'add'); break;
    case 'edDiv': if (s && s.editor) { s.editor.draft.div = el.dataset.v; s.editor.err = ''; render(); } break;
    case 'edKind': if (s && s.editor) { const d = s.editor.draft; d.kind = el.dataset.v; d.period = null; d.periods = []; s.editor.err = ''; render(); } break;
    case 'edPeriod': if (s && s.editor) {
      const d = s.editor.draft; const n = Number(el.dataset.v);
      if (d.kind === 'result') d.periods = d.periods.includes(n) ? d.periods.filter((x) => x !== n) : [...d.periods, n];
      else d.period = n;
      s.editor.err = ''; render();
    } break;
    case 'edChip': if (s && s.editor) {
      const d = s.editor.draft; const q = ((S.data && S.data.settings.quickReasons) || []).find((x) => x.label === el.dataset.v) || {};
      d.reason = q.label || el.dataset.v;
      if (q.div && NEIS_DIVS.includes(q.div)) d.div = q.div;
      if (q.kind && KINDS[q.kind]) { if (d.kind !== q.kind) { d.period = null; d.periods = []; } d.kind = q.kind; }
      d.tag = q.tag || null;
      d.reasonChip = d.reason;
      render();
    } break;
    case 'edCancel': if (s) { s.editor = null; render(); } break;
    case 'edApply': if (s && s.editor) editorApply(s); break;
    case 'edDelete': if (s && s.editor) editorDelete(s); break;
    case 'discardEdits': if (s) { s.edits = {}; s.warnDirect = null; render(); } break;
    case 'applyEdits': if (s && s.phase === 'review') applyEdits(el.dataset.force === '1'); break;
    case 'backReview': if (s && s.phase === 'plan') { s.phase = 'review'; s.plan = null; render(); } break;
    case 'redoDate': if (s && s.phase === 'plan' && s.plan && s.plan.reverted.length) redoDate(); break;
    case 'planChoice': if (s && s.plan) { const en = s.plan.entries.find((x) => x.row.no === Number(el.dataset.no)); if (en) en.choice = el.dataset.v; render(); } break;
    case 'doSave': if (s && s.phase === 'plan' && !s.remoteChanged) doSave(); break;
    case 'confirmRoster': confirmRoster(); break;
    case 'cancelRoster': S.rosterConfirm = null; render(); break;
    case 'roster': importRoster(); break;
    case 'clearRoster': await store.clearRoster(); S.roster = null; toast('이 PC의 명단을 지웠습니다.'); render(); break;
    case 'clearAllAsk': S.rosterClearAsk = true; render(); break;
    case 'clearAllCancel': S.rosterClearAsk = false; render(); break;
    case 'clearAllOk': {
      S.rosterClearAsk = false;
      await store.clearRoster(); S.roster = null;
      try {
        if (S.data && (S.data.roster || S.drive.connected)) await clearDriveRoster();
        toast('이 PC와 드라이브의 명단을 지웠습니다.');
      } catch (err) { toast(`이 PC의 명단은 지웠지만 드라이브의 명단은 지우지 못했습니다. ${err.message || ''}`, true); }
      render(); break;
    }
    case 'rosterUpload':
      try { await pushRosterToDrive(S.roster.students); toast('명단을 구글 드라이브에 올렸습니다.'); } catch (err) { toast(`올리지 못했습니다. ${err.message || ''}`, true); }
      render(); break;
    case 'rosterLater': try { localStorage.setItem(ROSTER_LATER_KEY, '1'); } catch (err) { /* 무시 */ } render(); break;
    case 'sync': syncNow(false); break;
    case 'connect': connectDrive(); break;
    case 'disconnect': disconnectDrive(); break;
    case 'copyRedir':
      try { await navigator.clipboard.writeText(drive.redirectUrl()); toast('리디렉션 URI를 복사했습니다.'); }
      catch (err) { $('redir').select(); toast('복사하지 못했습니다. 주소를 직접 선택해 복사하세요.', true); }
      break;
    case 'import': $('importFile').value = ''; $('importFile').click(); break;
    case 'export': exportBackup(); break;
    default: break;
  }
});
document.addEventListener('input', (e) => {
  const id = e.target.dataset && e.target.dataset.prepReason;
  if (id && S.session && S.session.prep) S.session.prep.draft[id].reason = e.target.value;
  const ed = S.session && S.session.editor;
  if (ed && e.target.dataset.ed === 'reason') { ed.draft.reason = e.target.value; if (e.target.value !== ed.draft.reasonChip) ed.draft.tag = null; }
});
document.addEventListener('change', (e) => {
  const ack = e.target.dataset && e.target.dataset.ack;
  if (ack && S.session && S.session.plan) {
    const en = S.session.plan.entries.find((x) => x.row.no === Number(ack));
    if (en) { en.ack = !!e.target.checked; render(); }
    return;
  }
  const ed = S.session && S.session.editor;
  if (ed && e.target.dataset && e.target.dataset.ed === 'no') { ed.no = e.target.value ? Number(e.target.value) : ''; ed.err = ''; render(); }
});
$('importFile').addEventListener('change', (e) => { const f = e.target.files[0]; if (f) importBackup(f); });

chrome.tabs.onActivated.addListener(() => detect());
chrome.tabs.onUpdated.addListener((id, info) => { if (info.status === 'complete') detect(); });

// ---------- 새 버전 안내 띠 ----------
// 패널이 열릴 때 1회 확인. 받기 실패는 조용히 무시. 일괄 입력·저장 중에도 띠만 보이고 다른 동작은 하지 않음.
async function checkUpdate() {
  try {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 8000);
    const res = await fetch(VERSION_URL, { cache: 'no-store', credentials: 'omit', signal: ctl.signal });
    clearTimeout(timer);
    if (!res.ok) return;
    const j = await res.json();
    if (!j || typeof j.version !== 'string' || !/^\d+(\.\d+)*$/.test(j.version)) return;
    const mine = chrome.runtime.getManifest().version;
    if (compareVersions(mine, j.version) >= 0) return;
    const zip = typeof j.zip === 'string' && /^[\w.-]+\.zip$/.test(j.zip) ? j.zip : 'attendance-extension.zip';
    const band = $('updateBand');
    band.innerHTML = `<span class="update-band-text">새 버전 <b class="num">${esc(j.version)}</b>이 있습니다</span>
      <a class="btn btn-secondary btn-sm" href="${esc(APP_BASE + zip)}" target="_blank" rel="noopener" data-testid="update-download">내려받기</a>
      <a class="btn btn-ghost btn-sm" href="${esc(APP_BASE + 'guide.html#ext-update')}" target="_blank" rel="noopener">방법</a>`;
    band.hidden = false;
  } catch (e) { /* 조용히 무시 */ }
}

// ---------- 시작 ----------
(async function init() {
  checkUpdate();
  [S.data, S.roster, S.drive, S.excl] = await Promise.all([store.loadData(), store.loadRoster(), store.loadDriveState(), store.loadExcluded()]);
  await pruneExcl();
  render();
  await detect();
  setInterval(() => { if (!document.hidden) detect(); }, 3000);
  if (S.drive.connected && drive.hasClientId()) syncNow(false, true);
})();
