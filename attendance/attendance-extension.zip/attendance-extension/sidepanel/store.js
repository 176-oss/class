// chrome.storage.local 저장 (키 이름은 앱 localStorage 와 같음: ah.data, ah.roster)
import { STORAGE_KEY, ROSTER_KEY, normalizeData } from '../shared/model.js';

export const DRIVE_STATE_KEY = 'ah.drive';

export async function loadData() {
  const o = await chrome.storage.local.get(STORAGE_KEY);
  return o[STORAGE_KEY] ? normalizeData(o[STORAGE_KEY]) : null;
}
export async function saveData(data) {
  await chrome.storage.local.set({ [STORAGE_KEY]: data });
}
export async function loadRoster() {
  const o = await chrome.storage.local.get(ROSTER_KEY);
  return o[ROSTER_KEY] || null;
}
export async function saveRoster(roster) {
  await chrome.storage.local.set({ [ROSTER_KEY]: roster });
}
export async function clearRoster() {
  await chrome.storage.local.remove(ROSTER_KEY);
}
export async function loadDriveState() {
  const o = await chrome.storage.local.get(DRIVE_STATE_KEY);
  return o[DRIVE_STATE_KEY] || { connected: false, lastSyncAt: null };
}
export async function saveDriveState(s) {
  await chrome.storage.local.set({ [DRIVE_STATE_KEY]: s });
}

// 백업 파일(앱에서 내보낸 JSON) 형식 확인
export function parseBackup(text) {
  let obj;
  try { obj = JSON.parse(text); } catch (e) { throw new Error('JSON 파일이 아닙니다.'); }
  if (obj && !Array.isArray(obj.records) && obj.data && Array.isArray(obj.data.records)) obj = obj.data;
  if (!obj || typeof obj !== 'object' || !Array.isArray(obj.records)) throw new Error('출결관리 도우미 백업 파일이 아닙니다 (records 항목 없음).');
  if (obj.schema && obj.schema !== 1) throw new Error(`지원하지 않는 파일 버전입니다 (schema ${obj.schema}).`);
  const bad = obj.records.filter((r) => !r || !r.id || !r.date || !r.no || !r.kind || !r.div);
  if (bad.length) throw new Error(`형식이 올바르지 않은 기록이 ${bad.length}건 있습니다.`);
  // 기록(records) 안의 이름은 계속 거부. 최상위 roster 필드는 허용 (병합할 때 sanitizeRoster 를 통과)
  if (obj.records.some((r) => 'name' in r || 'stuFlnm' in r)) throw new Error('기록에 학생 이름이 들어 있는 파일은 가져오지 않습니다.');
  return obj;
}

// 나이스 자동 입력에서 제외된 기록 (이 PC에만): { [recordId]: {reason, message, recUpdatedAt, at} }
export const EXCL_KEY = 'ah.neisExcluded';
export async function loadExcluded() {
  const o = await chrome.storage.local.get(EXCL_KEY);
  return o[EXCL_KEY] || {};
}
export async function saveExcluded(m) {
  await chrome.storage.local.set({ [EXCL_KEY]: m });
}
